//
//  TabBarHandle.m
//  MagookReader
//
//  Created by tailhuang on 15/9/21.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "ScanHandle.h"
#import "SVProgressHUD.h"
@implementation ScanHandle
+(void )handleUrl:(NSString *)url completedBlock:(void (^)(id))block{
    /**
     *  url=”{businessServer}/qrcode/query”
     */
    NSString *URL=[NSString stringWithFormat:@"%@qrcode/query",BUSSINESSSERVER];
    /**
     *  "userid":int,// 用户id

     "orgid": string, // 机构id,

     "qrstring":string, //麦格版新增, 二维码扫描原始内容

     "qrid":int, //从二维码扫描信息中获取的id数字,如果没有qrid信息,则赋值为0

     "device":{device}
     */

    [LogManager logWithViewID:@7 action:@"scan" info:url];

    NSDictionary *param =@{
                           @"userid":[UserModel sharedUser].userid,
                           @"orgid":@"magook",
                           @"qrstring":url,
                           @"qrid":@0,
                           @"device":DEVICE

                           };
    [SVProgressHUD showWithStatus:@"加载中" maskType:SVProgressHUDMaskTypeClear];
    [NSOperation POST:URL parameters:param success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [SVProgressHUD dismiss];
        NSLog(@"扫描结果===%@",[responseObject JSONString]);
        if ([[responseObject objectForKey:@"status"] isEqualToNumber:@1]) {
            if (block) {
                block(responseObject);
            }
        }else{
            [ZBHud showErrorWithMessage:responseObject[@"message"]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SVProgressHUD dismiss];

    }];

}
@end
