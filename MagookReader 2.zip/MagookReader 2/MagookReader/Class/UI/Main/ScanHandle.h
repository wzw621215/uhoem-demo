//
//  TabBarHandle.h
//  MagookReader
//
//  Created by tailhuang on 15/9/21.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ScanHandle : NSObject
+ (void)handleUrl:(NSString *)url
             completedBlock:(void (^)(id root))block;
@end
