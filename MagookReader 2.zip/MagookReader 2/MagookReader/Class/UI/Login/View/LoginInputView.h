//
//  LoginInputView.h
//  MagookReader
//
//  Created by tailhuang on 15/9/6.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginHadle.h"
@interface LoginInputView : UIView
@property (nonatomic, assign)BOOL isVerify;

@end
