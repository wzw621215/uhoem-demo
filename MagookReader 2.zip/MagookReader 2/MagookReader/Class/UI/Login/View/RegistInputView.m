//
//  RegistInputView.m
//  MagookReader
//
//  Created by tailhuang on 15/9/9.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "RegistInputView.h"

@interface RegistInputView()

@end
@implementation RegistInputView

- (IBAction)VerifyButtonClick:(UIButton *)sender {

    [self endEditing:YES];

    [LoginHadle sendVerifyCodeToTelNumber:self.userNameTF.text verifyCodeType:self.type target:sender];
}

//收起键盘
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self endEditing:YES];

}
-(void)awakeFromNib{
    self.passWordTF.secureTextEntry=YES;
}

@end
