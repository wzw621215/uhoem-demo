//
//  LoginHadle.h
//  MagookReader
//
//  Created by tailhuang on 15/9/8.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef NS_OPTIONS(NSInteger, InfoTpe){
    InfoTypeNickName,
    InfoTypeSex,
    InfoTypeEmail
};
typedef NS_ENUM(NSInteger, VerifyCodeType){
    VerifyCodeTypeLogin,
    VerifyCodeTypeReset,
    VerifyCodeTypeRegister,
    VerifyCodeTypeBundle
};
@class UserModel;
@interface LoginHadle : NSObject
//发送验证码
+(void)sendVerifyCodeToTelNumber:(NSString *)telNum verifyCodeType:(VerifyCodeType)verifyCodeType target:(UIButton *)button;
//登录
+(BOOL)loginWithUserName:(NSString *)userName passWord:(NSString *)passWord isVerify:(BOOL)isVerify;
//+(void)loginWithUserName:(NSString *)userName passWord:(NSString *)passWord isVerify:(BOOL)isVerify Success:(void (^)(BOOL isSuccess))successBlock;
//修改密码
+(void)resetWithUserName:(NSString *)userName verifyCode:(NSString *)verifyCode newPassWord:(NSString *)newPassWord;
//注册
+(void)registWithUserName:(NSString *)userName verifyCode:(NSString *)verifyCode passWord:(NSString *)passWord;

//用户服务协议
+(NSURLRequest *)customServiveRequest;
//提交用户信息
+(void)resetUserInfo;
//登出
+(void)logoutWithSuccess:(void (^)(BOOL isSuccess))successBlock;

+(void)getRoleData;
@end
