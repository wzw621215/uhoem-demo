//
//  CustomServiceViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/9.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "CustomServiceViewController.h"
#import "LoginHadle.h"
@interface CustomServiceViewController ()

@end

@implementation CustomServiceViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title=@"麦格用户服务协议";
    UIBarButtonItem *left = [UIBarButtonItem itemWithTarget:self action:@selector(back) image:@"back" highImage:@"back_highlight"];
    self.navigationItem.leftBarButtonItem=left;


    UIWebView *web=[[UIWebView alloc]initWithFrame:self.view.frame];

    [web loadRequest:[LoginHadle customServiveRequest]];

    [self.view addSubview:web];
    // Do any additional setup after loading the view.
}
-(void)back{

    [self.navigationController popViewControllerAnimated:YES];
}
@end
