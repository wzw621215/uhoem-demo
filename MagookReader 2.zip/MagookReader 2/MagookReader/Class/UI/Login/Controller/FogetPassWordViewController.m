//
//  FogetPassWordViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/9.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "FogetPassWordViewController.h"
#import "RegistInputView.h"
#import "LoginHadle.h"
@interface FogetPassWordViewController ()
{
    UIView* _backView;
    RegistInputView *_inputView;
}
@end

@implementation FogetPassWordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    OBSERVER(ResetPassWordSuccessNotification, @selector(back));

    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"bg"]]];

    [self configNav];
    [self createInputView];
    [self createButton];
}
-(void)dealloc{
    REMOVEOBSERVER;
}
-(void)createButton{

    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];

    button.frame=CGRectMake(30, CGRectGetMaxY(_backView.frame)+20, _inputView.width, 44);

    [button setTitle:@"立即重置" forState:UIControlStateNormal];

    [button cutCornerRadius:5];

    [button setBackgroundColor:COLOR];

    [button addTarget:self action:@selector(resetPassWord) forControlEvents:UIControlEventTouchUpInside];


    [self.view addSubview:button];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_backView.mas_bottom).with.offset(Margin);
        make.centerX.equalTo(self.view);
        make.width.mas_equalTo(280);
        make.height.mas_equalTo(44);
    }];

}

#pragma mark -重置密码
-(void)resetPassWord{

    [LoginHadle resetWithUserName:_inputView.userNameTF.text verifyCode:_inputView.verifyCodeTF.text newPassWord:_inputView.passWordTF.text ];
    [self.view endEditing:YES];
    
}
-(void)createInputView{

    _backView =[[UIView alloc]initWithFrame:CGRectMake(20, 100, SCREEN_WIDTH-40, 220)];
    _backView.backgroundColor =RGB(255, 255, 255, 0.5);

    _backView.layer.cornerRadius =10;
    _backView.layer.masksToBounds=YES;
    _inputView = LOADNIBNAME(@"RegistInputView");
    _inputView.type=VerifyCodeTypeReset;
    
    [_backView addSubview:_inputView];
    [_inputView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(UIEdgeInsetsZero);
    }];

    [self.view addSubview:_backView];
    [_backView mas_makeConstraints:^(MASConstraintMaker *make) {
       
        make.size.mas_equalTo(CGSizeMake(300, 190));
        make.centerX.equalTo(self.view);
        make.top.mas_equalTo(NAV_HEIGHT+Margin);
    }];


}
-(void)configNav{
    self.title =@"忘记密码";
    self.navigationController.navigationBar.barTintColor =COLOR;
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]}];

    UIBarButtonItem *left = [UIBarButtonItem itemWithTarget:self action:@selector(back) image:@"back" highImage:@"back_highlight"];
    self.navigationItem.leftBarButtonItem=left;

}
-(void)back{

    if (self.navigationController.viewControllers.count>1) {
    [self.navigationController popViewControllerAnimated:YES];
    }else{
    [self.navigationController dismissViewControllerAnimated:YES completion:^{

    }];
    }

}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}
@end
