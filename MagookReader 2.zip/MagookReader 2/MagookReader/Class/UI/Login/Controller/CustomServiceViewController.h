//
//  CustomServiceViewController.h
//  MagookReader
//
//  Created by tailhuang on 15/9/9.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomServiceViewController : UIViewController

@end
