//
//  UserModel.h
//  MagookReader
//
//  Created by tailhuang on 15/9/8.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicModel.h"
//typedef NS_OPTIONS(NSUInteger, UserPermissionStyle) {
//    UserPermissionStyleDoNotPurchased,
//    UserPermissionStylePurchased,
//    UserPermissionStyleOutOfDate
//
//};
@interface UserModel : BasicModel
@property (nonatomic, copy) NSString *status;
@property (nonatomic, copy) NSString *usertoken;
@property (nonatomic, strong) NSNumber *userid;
@property (nonatomic, copy) NSString *nick;
@property (nonatomic, strong) NSNumber *assets;
@property (nonatomic, strong) NSNumber *age;
@property (nonatomic, strong) NSNumber *level;
@property (nonatomic, copy) NSString *username;
@property (nonatomic, copy) NSString *email;
@property (nonatomic, strong) NSNumber *sex;
@property (nonatomic, copy) NSString *phonenum;


@property (nonatomic ,copy) NSString *userHash;
//是否全库VIP,1是，0不是
//@property (nonatomic ,strong) NSMutableArray *roleDataArray;
@property (nonatomic, strong) NSNumber *iswholelib;
//VIP期限
//wholelibexpiredate==99991231表示终身VIP
@property (nonatomic, strong) NSNumber *wholelibexpiredate;

@property (nonatomic, strong) NSMutableArray *puchasedArray;

+(instancetype)sharedUser;
+(instancetype)loginWithDic:(NSDictionary *)dic;
+(void)removeUser;
//-(UserPermissionStyle)checkPermissionWithMagazineID:(NSNumber *)magazineid;
@end
