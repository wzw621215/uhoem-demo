//
//  DefaultPageView.h
//  MagookReader
//
//  Created by tailhuang on 15/9/15.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DefaultPageView : UIView
@property (weak, nonatomic) IBOutlet UIImageView *defaultImageView;
@property (weak, nonatomic) IBOutlet UILabel *defaultLab;
@property (weak, nonatomic) IBOutlet UIButton *button;
@end
