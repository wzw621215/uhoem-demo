//
//  MGLibRightViewController.h
//  MagookReader
//
//  Created by zhoubin on 15/11/3.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import "BasicMGLibRightViewController.h"
@interface MGLibRightViewController : BasicMGLibRightViewController

@end
