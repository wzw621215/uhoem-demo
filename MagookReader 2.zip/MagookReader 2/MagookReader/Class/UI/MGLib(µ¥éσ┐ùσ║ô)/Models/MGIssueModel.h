//
//  MGIssueModel.h
//  MagookReader
//
//  Created by tailhuang on 15/9/11.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicModel.h"
@class SDWebImageCombinedOperation;
@interface MGIssueModel : BasicModel
@property (nonatomic, strong) NSNumber *price0;
@property (nonatomic, strong) NSNumber *price1;
@property (nonatomic, strong) NSNumber *start;
@property (nonatomic, copy) NSString *issuename;
@property (nonatomic, strong) NSNumber *count;
@property (nonatomic, strong) NSNumber *issueid;
@property (nonatomic, copy) NSString *magazinename;
@property (nonatomic, copy) NSString *path;
@property (nonatomic, copy) NSString *guid;
@property (nonatomic, strong) NSNumber *magazineid;
@property (nonatomic, strong) NSNumber *toll;

@property (nonatomic, assign) BOOL isSelected;

//下载相关的属性
//已下载数量
@property (nonatomic, assign) NSInteger downloadedNumber;

//当前operatiopn用于暂停及判断是否正在下载
//@property (nonatomic, strong) AFHTTPRequestOperation *operation;
@property (nonatomic, strong) SDWebImageCombinedOperation *sd_operation;
//是否为推送的新杂志
@property (nonatomic ,assign) BOOL isNewMagazine;

@property (nonatomic ,assign) NSInteger stepValue;

+(instancetype)modelWithDic:(NSDictionary *)dic;

@end
