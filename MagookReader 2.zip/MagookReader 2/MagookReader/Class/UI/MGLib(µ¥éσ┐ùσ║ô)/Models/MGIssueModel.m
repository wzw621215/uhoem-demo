//
//  MGIssueModel.m
//  MagookReader
//
//  Created by tailhuang on 15/9/11.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "MGIssueModel.h"
#import "ApnsModel.h"
#import "ShoppingCartDataManager.h"
#import "MJExtension.h"
#define PATH [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"apns.plist"]
@interface MGIssueModel ()
@property (nonatomic ,strong) NSMutableArray *magazinePushArray;
@end

@implementation MGIssueModel
MJExtensionCodingImplementation
+(instancetype)modelWithDic:(NSDictionary *)dic{
    MGIssueModel *model = [[self alloc]init];
    
    [model setValuesForKeysWithDictionary:dic];

    return model;
}
-(void)setMagazineid:(NSNumber *)magazineid{
    if ([magazineid isKindOfClass:[NSString class]]) {
        NSNumber *mgid=[NSNumber numberWithInteger:[magazineid integerValue]];
        _magazineid=mgid;
    }else{
        _magazineid=magazineid;
    }

}

-(BOOL)isNewMagazine{
    for (ApnsModel *model in self.magazinePushArray) {

        NSArray *array=[NSArray arrayWithArray:model.newmagazine[@"magazineid"]];
        for (NSNumber *magazineid in array) {
            if ([self.magazineid isEqualToNumber:magazineid]) {
                return YES;
            }
        }
    }
    return NO;
}
-(NSMutableArray *)magazinePushArray{
    if (!_magazinePushArray) {
        _magazinePushArray=[NSMutableArray array];
        
        NSArray *temp=[NSArray arrayWithContentsOfFile:PATH];
        
        for (NSDictionary *dic in temp) {
            ApnsModel *model = [ApnsModel modelWithDic:dic];
            if (model.type==ApnsTypeNewmagazine&&model.isRead==NO) {
                [_magazinePushArray addObject:model];
            }
            
        }
    }
    return _magazinePushArray;
}
@end
