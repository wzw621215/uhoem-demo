//
//  LibDataModel.h
//  MagookReader
//
//  Created by tailhuang on 15/9/13.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicModel.h"

@interface LibDataModel : BasicModel
@property (nonatomic, strong) NSNumber *category;
@property (nonatomic, strong) NSNumber *page;
@property (nonatomic, strong) NSMutableArray *dataArray;

@end
