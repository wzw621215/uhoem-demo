//
//  LibDataModel.m
//  MagookReader
//
//  Created by tailhuang on 15/9/13.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "LibDataModel.h"
#import "MJExtension.h"
@implementation LibDataModel
MJExtensionCodingImplementation
-(NSNumber *)page{
    if (_page==nil) {
        _page=@1;
    }
    return _page;
}
@end
