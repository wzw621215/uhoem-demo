//
//  MGLibHandle.h
//  MagookReader
//
//  Created by tailhuang on 15/9/11.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface MGLibHandle : NSObject
+(void)getRightButtonTitlesCompletionHandler:(void (^)( id obj)) handler ;
+(void)getMGListDataWithCategory:(NSNumber *)category page:(NSNumber *)page completionHandler:(void (^)(id obj)) handler;
+(void)getMGListCoverWithPath:(NSString *)path magezineID:(NSNumber *)magezineID issueid:(NSNumber *)issueid completionHandler:(void (^)( NSString *url))handler;
@end
