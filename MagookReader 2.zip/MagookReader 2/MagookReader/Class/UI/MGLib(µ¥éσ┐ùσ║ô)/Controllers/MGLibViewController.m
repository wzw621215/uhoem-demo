//
//  MGlibViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/9.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "MGLibViewController.h"
#import "MGNavigationConroller.h"
#import "MGLibHandle.h"
//#import "MGLibCell.h"
#import "MGIssueModel.h"
#import "CategoryModel.h"
#import "LibDataModel.h"
#import "ReadingViewController.h"
#import "MGLibCollectionViewController.h"
#import "MGLibRightViewController.h"
#define ARCHIVERPATH [CACHEPATH stringByAppendingPathComponent:MGLIBARCHIVER]
@interface MGLibViewController ()
//@property (nonatomic ,strong) MGLibRightViewController *rightVC;

@end

@implementation MGLibViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    [self configNav];
    [self createCollectionView];
    [self getOringinData];
    [self createRightViewWithVCClass:[MGLibRightViewController class]];
}
#pragma mark -导航栏右侧按钮
-(void)configNav{
    [(MGNavigationConroller*)self.navigationController addItemWithType:MGRightItemTypeSearch inVc:self];

    [(MGNavigationConroller*)self.navigationController addItemWithType:MGRightItemTypeScan inVc:self];
}
#pragma mark- 创建collectionView
-(void)createCollectionView{
    self.collectionVC = [[MGLibCollectionViewController alloc]init];
    self.collectionVC.view.autoresizingMask=UIViewAutoresizingNone;

    __weak typeof(self)  weakSelf=self;
    
    self.collectionVC.block=^(MGIssueModel *model){
        if ([AppController sharedController].netWorkStatus) {
            ReadingViewController*vc=[ReadingViewController new];
            vc.model=model;
            [weakSelf.navigationController pushViewController:vc animated:YES];
        }else{
            [ZBHud showErrorWithMessage:@"网络连接失败!"];
        }
        
    };
    
    [self.view addSubview:self.collectionVC.view];
    
    UIEdgeInsets padding = UIEdgeInsetsMake(NAV_HEIGHT, 0, TAB_HEIGHT, RightTableW);
    [self.collectionVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view).with.insets(padding);
    }];
    
}



@end
