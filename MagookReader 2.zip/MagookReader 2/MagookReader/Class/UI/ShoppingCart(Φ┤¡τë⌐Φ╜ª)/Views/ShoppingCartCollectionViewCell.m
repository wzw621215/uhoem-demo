//
//  ShoppingCartCollectionViewCell.m
//  MagookReader
//
//  Created by tailhuang on 15/9/14.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "ShoppingCartCollectionViewCell.h"
#import "MGIssueModel.h"
#import "MGLibHandle.h"
#import "UIImageView+WebCache.h"
@interface ShoppingCartCollectionViewCell()


@property (weak, nonatomic) IBOutlet UIImageView *coverImageView;

@property (weak, nonatomic) IBOutlet UILabel *titleLab;
@end
@implementation ShoppingCartCollectionViewCell
- (IBAction)cancelButtonClick:(UIButton *)sender {
    //删除该模型block回调
    [LogManager logWithViewID:@34 action:@"favor_del"];
    self.block(self.model);
}
- (void)awakeFromNib {
    
    if (iPad) {
        self.titleLab.font=FONTIPAD;
    }
    
}

-(void)setModel:(MGIssueModel *)model{
    _model=model;
    self.titleLab.text=model.magazinename;

    [MGLibHandle getMGListCoverWithPath:model.path magezineID:model.magazineid issueid:model.issueid completionHandler:^(NSString *url) {
        [self.coverImageView sd_setImageWithURL:[NSURL URLWithString:url] placeholderImage:[UIImage imageNamed:@"封面"]];

    }];


}


@end
