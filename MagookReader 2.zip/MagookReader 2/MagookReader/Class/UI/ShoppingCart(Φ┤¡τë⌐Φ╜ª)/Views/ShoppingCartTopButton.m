//
//  ShoppingCartTopButton.m
//  MagookReader
//
//  Created by tailhuang on 15/9/14.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "ShoppingCartTopButton.h"

@implementation ShoppingCartTopButton

-(id)initWithCoder:(NSCoder *)aDecoder{

    if (self= [super initWithCoder:aDecoder]) {
        [self configUI];
    }

    return self;
}

-(instancetype)initWithFrame:(CGRect)frame{
    if (self= [super initWithFrame:frame]) {
        
        [self configUI];
    }
    
    return self;

}
-(void)configUI{
    self.userInteractionEnabled=NO;
    
    self.lab1 = [[UILabel alloc]init];
    
    if (iPad) {
        self.lab1.font=[UIFont systemFontOfSize:15.0f];
    }else{
        self.lab1.font=[UIFont systemFontOfSize:10.0f];
    }
    self.lab1.textAlignment=NSTextAlignmentCenter;
    
    [self addSubview:self.lab1];
    
    self.lab2 =[[UILabel alloc]init];
    
    if (iPad) {
        self.lab2.font=FONTIPAD;
    }else{
        self.lab2.font=[UIFont systemFontOfSize:13.0f];
    }
    self.lab2.textAlignment=NSTextAlignmentCenter;
    [self addSubview:self.lab2];
    
    self.selected=NO;
    
    self.layer.borderWidth=1;
    [self cutCornerRadius:5];
}
-(void)layoutSubviews{

    self.lab1.frame=CGRectMake(0, 0, self.width, self.height/2);
    self.lab2.frame=CGRectMake(0, self.height/2, self.width, self.height/2);
    if (self.selected) {
        self.lab1.textColor=COLOR;
        self.lab2.textColor=COLOR;

        self.layer.borderColor=[COLOR CGColor];

    }else{
        self.lab1.textColor=[UIColor lightGrayColor];
        self.lab2.textColor=[UIColor lightGrayColor];
        self.layer.borderColor=[[UIColor lightGrayColor] CGColor];
    }
}


@end
