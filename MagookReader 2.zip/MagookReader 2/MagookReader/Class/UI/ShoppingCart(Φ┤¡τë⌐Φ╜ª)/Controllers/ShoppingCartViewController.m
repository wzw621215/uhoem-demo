//
//  ShoppingCartViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/14.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "ShoppingCartViewController.h"
@interface ShoppingCartViewController ()

@end

@implementation ShoppingCartViewController

- (void)viewDidLoad {

    [super viewDidLoad];

    OBSERVER(FinishPayNotification, @selector(finishPay));
    [self.settlementView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.height.mas_equalTo(TAB_HEIGHT);
        make.bottom.equalTo(self.view).with.offset(-TAB_HEIGHT);
    }];
}
-(void)finishPay{
    //购买成功跳转到杂志架
    self.tabBarController.selectedIndex    = self.tabBarController.viewControllers.count-4;
}

-(void)dealloc{
    REMOVEOBSERVER;
}

#pragma  mark -创建collectionView
-(void)createCollectionView{
    self.collectionVC                      = [[ShoppingCartCollectionViewController alloc]init];
    [self.view addSubview:self.collectionVC.view];
    UIEdgeInsets padding                   = UIEdgeInsetsMake(NAV_HEIGHT+60, 0, TAB_HEIGHT*2, 0);
    [self.collectionVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view).with.insets(padding);
    }];
}

@end
