//
//  BasicShoppingCartViewController.h
//  MagookReader
//
//  Created by tailhuang on 15/9/21.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicViewController.h"
#import "ShoppingCartCollectionViewController.h"
#import "SettlementView.h"
#import "DefaultPageView.h"

@interface BasicShoppingCartViewController : BasicViewController
@property (strong, nonatomic) ShoppingCartCollectionViewController *collectionVC;
@property (strong, nonatomic) DefaultPageView *defaultPage;
@property (strong, nonatomic) SettlementView *settlementView;
-(void)shoppingCartDidChange;
@end
