//
//  ShoppingCartViewController.h
//  MagookReader
//
//  Created by tailhuang on 15/9/14.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicViewController.h"
#import "BasicShoppingCartViewController.h"
@interface ShoppingCartViewController : BasicShoppingCartViewController
//-(void)shoppingCartDidChange;
@end
