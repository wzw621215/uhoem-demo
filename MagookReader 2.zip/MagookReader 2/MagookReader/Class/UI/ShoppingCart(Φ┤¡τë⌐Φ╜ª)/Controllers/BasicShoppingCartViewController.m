//
//  ShoppingCartViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/14.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicShoppingCartViewController.h"
#import "ShoppingCartTopButton.h"
#import "ShoppingCartDataManager.h"
#import "MGNavigationConroller.h"
#import "SettlementModel.h"
#import "MGIssueModel.h"
#import "SettleViewController.h"
#import "OderConfirnViewController.h"
#import "DXAlertView.h"
#import "LoginViewController.h"
@interface BasicShoppingCartViewController ()

@end

@implementation BasicShoppingCartViewController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden=NO;
    self.navigationController.navigationBar.barTintColor = COLOR;
    NSUInteger count=[[[ShoppingCartDataManager sharedManager] allData] count];
    for (int i                             = 0; i<4; i++) {
        ShoppingCartTopButton *bt              = (ShoppingCartTopButton *)[self.view viewWithTag:300+i];
        
        if (count==0) {
            bt.hidden                              = YES;
        }else{
            bt.hidden                              = NO;
        }
        
    }
    if ([[[ShoppingCartDataManager sharedManager]allData]count]!=0) {

        if (_defaultPage) {
            [_defaultPage removeFromSuperview];
        }

        if (self.collectionVC==nil) {
            [self createCollectionView];
        }
        [self updateDataSourse];
        
    }else{
        [self.view addSubview:self.defaultPage];
        [self.defaultPage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(UIEdgeInsetsZero);
        }];
        self.settlementView.hidden             = YES;
        
    }
}
#pragma mark -懒加载结算View
-(SettlementView *)settlementView{
    if (!_settlementView) {
        _settlementView                        = LOADNIBNAME(@"SettlementView");
//        _settlementView.frame                  = CGRectMake(0, SCREEN_HEIGHT-2*TAB_HEIGHT, SCREEN_WIDTH, TAB_HEIGHT);
        
        __weak typeof(self) weakSelf           = self;
        
        _settlementView.settleBlock=^(NSInteger amount,NSInteger number){

            if ([AppController sharedController].netWorkStatus==NetWorkStatusNotReachable) {
                [ZBHud showErrorWithMessage:@"网络连接失败!"];
                return ;
            }
            if (([UserModel sharedUser].userHash==nil)&&INREVIEW) {
                NSLog(@"获取userHash失败");
                return;
            }
            SettlementModel *model                 = [SettlementModel new];
            
            NSMutableArray *array=[NSMutableArray new];
            for (MGIssueModel *m in [[ShoppingCartDataManager sharedManager]allData]) {
                
            NSDictionary*d=@{@"magazineid":m.magazineid,@"buypackageid":BUYPACKAGE30,@"quantity":@1};
                [array addObject:d];
            }
            model.type                             = OrdertypeShoppingCart;
            model.magdata                          = array;
            model.number                           = number;
            model.amount                           = amount;
            
            NSLog(@"=================%@--->%ld",[UserModel sharedUser].usertoken?@"已登录":@"未登录",INREVIEW);
            
            if ([UserModel sharedUser].usertoken) {
                //已登录
                //             订单支付
                SettleViewController *settle =[SettleViewController new];
                settle.model                           = model;
                [weakSelf.navigationController pushViewController:settle animated:YES];
                
            }else if (INREVIEW){
                //未登录，审核中
                DXAlertView *alert              = [[DXAlertView alloc] initWithTitle:@"温馨提示" contentText:@"尊敬的用户，您尚未登录\n您购买的期刊将只能在当前设备上阅览\n我们强烈建议您在注册/登录之后再继续结算!" leftButtonTitle:@"继续结算" rightButtonTitle:@"去登录"];
                [alert show];
                alert.leftBlock                 = ^() {
                    NSLog(@"继续结算");
                    SettleViewController *settle =[SettleViewController new];
                    settle.model                           = model;
                    [weakSelf.navigationController pushViewController:settle animated:YES];
                };
                alert.rightBlock                = ^() {
                    NSLog(@"去结算");
                    LoginViewController *vc =[LoginViewController new];
                    [weakSelf.navigationController pushViewController:vc animated:YES];

                };
                alert.dismissBlock              = ^() {

                };

                
            }else{
                //未登录，非审核
                //订单确认
                OderConfirnViewController *oderConfirn = [OderConfirnViewController new];
                oderConfirn.model                      = model;
                [weakSelf.navigationController pushViewController:oderConfirn animated:YES];
            }
            
        };
    }
    return _settlementView;
    
}
#pragma mark -懒加载默认页
-(DefaultPageView *)defaultPage{
    if (!_defaultPage) {
    _defaultPage                           = LOADNIBNAME(@"DefaultPageView");
    }
    return _defaultPage;
}
- (void)viewDidLoad {

    [super viewDidLoad];

    self.title=@"购物车";

    
    [(MGNavigationConroller*)(self.navigationController) addItemWithType:MGRightItemTypeVIP inVc:self];
    self.view.backgroundColor              = BKCOLOR;
    OBSERVER(ShoppingCartDidChangeNotification,@selector(shoppingCartDidChange));


    //顶部文本
    [self createTopItems];

    [self.view addSubview:self.settlementView];

    [self.settlementView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(self.view);
        make.left.equalTo(self.view);
        make.height.mas_equalTo(TAB_HEIGHT);
        make.bottom.equalTo(self.view);
    }];

}

-(void)dealloc{
    NSLog(@"销毁购物车");
    REMOVEOBSERVER;
}

#pragma mark -监听购物车改变
-(void)shoppingCartDidChange{
    
    [self updateButtons];
    
    [self updateDataSourse];
    NSUInteger count=[[[ShoppingCartDataManager sharedManager] allData] count];
    NSString *badgeValue =[NSString stringWithFormat:@"%lu",count];
    
    badgeValue=[badgeValue isEqualToString:@"0"]?nil:badgeValue;
    
    self.tabBarItem.badgeValue             = badgeValue;
    
    if (count==0) {
        
        [self.view addSubview:self.defaultPage];
        [self.defaultPage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(UIEdgeInsetsZero);
        }];
        self.settlementView.hidden             = YES;
        
    }else{
        if (_defaultPage) {
            [_defaultPage removeFromSuperview];
        }
        self.settlementView.hidden             = NO;
    }
    
    for (int i                             = 0; i<4; i++) {
        ShoppingCartTopButton *bt              = (ShoppingCartTopButton *)[self.view viewWithTag:300+i];
        
        if (count==0) {
            bt.hidden                              = YES;
        }else{
            bt.hidden                              = NO;
        }
        
    }
    
}
//创建上方的按钮
-(void)createTopItems{
    
    UIButton *lastBt                       = nil;
    for (int i                             = 0;i<4 ;i++ ) {
        ShoppingCartTopButton *bt              = [[ShoppingCartTopButton alloc]init];
        bt.tag                                 = 300+i;
        
        [self.view addSubview:bt];
        [bt mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.height.mas_equalTo(40);
            make.top.mas_equalTo(NAV_HEIGHT+Margin);
            
            if ( lastBt )
            {
                make.left.equalTo(lastBt.mas_right).with.offset(Margin);
                make.width.equalTo(lastBt);
            }
            else
            {
                make.left.equalTo(self.view).with.offset(Margin);
                make.width.equalTo(self.view.mas_width).with.multipliedBy(0.25).and.offset(-12.5);
            }
        }];
        
        lastBt                                 = bt;
    }
    //更新状态
    [self updateButtons];
    
    
}

#pragma mark -更新上方按钮
-(void)updateButtons{
    
    NSArray *titileArray=@[@"1种包年套餐",@"5种包年套餐",@"10种包年套餐",@"20种包年套餐"];
    
    NSInteger count=[[[ShoppingCartDataManager sharedManager]allData] count];
    
    NSArray *countArray=[self caculateFeeWithCount:count];
    
    NSArray *plan =@[@"￥30",@"￥98",@"￥188",@"￥348"];
    
    NSMutableArray *priceArray=[NSMutableArray new];
    
    for (int i                             = 0; i<countArray.count; i++) {
        
        NSString *subTitleString               = [countArray[i] isEqualToNumber:@0]?plan[i]:[NSString stringWithFormat:@"%@x%@",plan[i],countArray[i]];
        [priceArray addObject:subTitleString];
        
    }
    
    for (int i                             = 0; i<4; i++) {
        ShoppingCartTopButton *bt              = (ShoppingCartTopButton *)[self.view viewWithTag:300+i];
        bt.lab1.text                           = titileArray[i];
        bt.lab2.text                           = priceArray[i];
        bt.selected=![countArray[i] isEqualToNumber:@0];
    }
    
    
}


//订单金额算法
-(NSArray *)caculateFeeWithCount:(NSInteger)count{
    NSInteger a[4]={20,10,5,1};
    NSInteger b[4];
    
    NSMutableArray *array =[NSMutableArray new];
    
    for (int i = 0 ;i<4;i++) {
        
        b[i]= count/a[i];
        
        count%=a[i];
    }
    
    for (int i = 3; i>=0; i--) {
        [array addObject:@(b[i])];
    }
    return array;
}

-(void)updateDataSourse{
    self.collectionVC.dataArray=[NSMutableArray arrayWithArray:[[ShoppingCartDataManager sharedManager]allData]];
}
#pragma  mark -创建collectionView
-(void)createCollectionView{
    self.collectionVC                      = [[ShoppingCartCollectionViewController alloc]init];
    [self.view addSubview:self.collectionVC.view];
    UIEdgeInsets padding                   = UIEdgeInsetsMake(NAV_HEIGHT+60, 0, TAB_HEIGHT, 0);
    [self.collectionVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view).with.insets(padding);
    }];

}

@end
