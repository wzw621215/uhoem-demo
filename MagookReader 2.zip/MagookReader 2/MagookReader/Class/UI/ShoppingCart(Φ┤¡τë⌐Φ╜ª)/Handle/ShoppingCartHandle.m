//
//  ShoppingCartHandle.m
//  MagookReader
//
//  Created by tailhuang on 15/10/15.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "ShoppingCartHandle.h"
#import "ShoppingCartDataManager.h"
#import "MGIssueModel.h"
#import "JSONKit.h"
#import "MGShelfHandle.h"
#import "MJExtension.h"
@implementation ShoppingCartHandle
+(void)sendShoppingCartDataToServer{

    NSString *url = [NSString stringWithFormat:@"%@order/appendshoppingcart",PURCHASSERVER];

    NSArray *dbDataArray=[NSArray arrayWithArray:[[ShoppingCartDataManager sharedManager]allData]];
    NSMutableArray *magazines=[NSMutableArray new];

    for (MGIssueModel *model in dbDataArray) {
        NSDictionary *d=[NSDictionary dictionaryWithObject:model.magazineid forKey:@"magazineid"];
        [magazines addObject:d];
    }

    NSDictionary *param =@{
                           @"userid":[UserModel sharedUser].userid,
                           @"userhash":[UserModel sharedUser].userHash,
                           @"usertoken":INREVIEW?@"inReview":[UserModel sharedUser].usertoken,
                           @"device":DEVICE,
                           @"magazines":magazines,
                           };

    NSData *postData=[param JSONData];

    NSMutableURLRequest *request =[NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];

    request.timeoutInterval=TimeOutInterval;
    [request setValue:@"POST" forKey:@"HTTPMethod"];

    [request setHTTPBody: postData];

    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {

        if (!connectionError) {
            NSLog(@"发送购物车数据到服务器成功");

        }else{
            NSLog(@"发送购物车数据到服务器失败%@",connectionError);

        }
        
    }];


}
+(void)getShoppingCartDataFromServerSuccess:(void (^)(NSArray *dataArray))complete{

    NSString *url =[NSString stringWithFormat:@"%@order/shoppingcart",PURCHASSERVER];
    NSDictionary *param =@{
                           @"userid":[UserModel sharedUser].userid,
                           @"userhash":[UserModel sharedUser].userHash,
                           @"usertoken":INREVIEW?@"":[UserModel sharedUser].usertoken,
                           @"device":DEVICE,
                           };
    NSData *postData=[param JSONData];

    NSMutableURLRequest *request =[NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];

    request.timeoutInterval=TimeOutInterval;
    
    [request setValue:@"POST" forKey:@"HTTPMethod"];

    [request setHTTPBody: postData];

    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {

        if (data) {

            NSDictionary *root=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            NSArray *dataArray=root[@"data"];

            NSMutableArray *array=[NSMutableArray new];

            NSLog(@"服务器购物车共有%ld条数据",dataArray.count);

            //计数器，用来保证全部数据遍历完毕
            __block int m=0;

            for (NSDictionary *d in dataArray) {

                //如果本地不存在该magazineid则网络请求数据
                if (![[ShoppingCartDataManager sharedManager]isExistsDataWithMagazineid:d[@"magazineid"]]) {


                    [MGShelfHandle getMagazinedataWithMagazineid:d[@"magazineid"] success:^(MGIssueModel *model) {

                        //将本地数据库不存在的model存入数据库
                        [[ShoppingCartDataManager sharedManager]insertDataWithModel:model];

                        [array addObject:model];

                        //不存在，则等到模型已经添加成功再加1
                         m++;

                        if (m==dataArray.count) {

                            complete(array);
                        }

                    }];

                }else{
                    //如果数据库存在，计数器直接加1
                    m++;
                }
            }

        }else{
            NSLog(@"%@",connectionError);
        }
        
    }];

}
@end
