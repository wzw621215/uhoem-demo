//
//  ShoppingCartHandle.h
//  MagookReader
//
//  Created by tailhuang on 15/10/15.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShoppingCartHandle : NSObject
+(void)sendShoppingCartDataToServer;
+(void)getShoppingCartDataFromServerSuccess:(void (^)(NSArray *dataArray))complete;
@end
