//
//  DetailModel.h
//  MagookReader
//
//  Created by tailhuang on 15/9/20.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicModel.h"

@interface DetailModel : BasicModel
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSNumber *level;
@property (nonatomic, copy) NSNumber *page;
@end
