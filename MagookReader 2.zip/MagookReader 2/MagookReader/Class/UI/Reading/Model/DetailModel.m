//
//  DetailModel.m
//  MagookReader
//
//  Created by tailhuang on 15/9/20.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "DetailModel.h"

@implementation DetailModel

@end
