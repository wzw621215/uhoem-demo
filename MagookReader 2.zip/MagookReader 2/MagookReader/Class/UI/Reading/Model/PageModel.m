//
//  PageModel.m
//  MagookReader
//
//  Created by tailhuang on 15/9/17.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "PageModel.h"

@implementation PageModel


@end
