//
//  YearModel.h
//  MagookReader
//
//  Created by tailhuang on 15/9/22.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicModel.h"
/**
count = 20;
 year = 2013;
 */
@interface YearModel : BasicModel
@property (nonatomic, strong) NSNumber *count;
@property (nonatomic, strong) NSNumber *year;

@end
