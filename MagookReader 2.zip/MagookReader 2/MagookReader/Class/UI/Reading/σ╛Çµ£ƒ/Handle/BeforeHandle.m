//
//  BeforeHandle.m
//  MagookReader
//
//  Created by tailhuang on 15/9/22.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BeforeHandle.h"
#import "SVProgressHUD.h"
@implementation BeforeHandle
+(void)getYearListWithMgID:(NSNumber *)ID completeBlock:(void (^)(id))success{
//url=”{businesscacheServer}/magazine/magazine_{magazineid}/year/year_{magazineid}.txt”

    [SVProgressHUD showWithStatus:@"加载中" maskType:SVProgressHUDMaskTypeClear];


    NSString *url=[NSString stringWithFormat:@"%@magazine/magazine_%@/year/year_%@.txt",BUSSINESCACHESSERVER,ID,ID];

    [NSURLConnection sendAsynchronousRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]] queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {

        [SVProgressHUD dismiss];

        if (data==nil) {
            [ZBHud showErrorWithMessage:@"连接服务器失败"];
            return ;
        }
        id root =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];

        success(root);

    }];
    
}
+(void)getDetailListWithMgID:(NSNumber *)ID atYear:(NSNumber *)year completeBlock:(void (^)(id))success{

    [SVProgressHUD showWithStatus:@"加载中" maskType:SVProgressHUDMaskTypeClear];

//    url=”{businesscacheServer}/magazine/magazine_{magazineid}/yearlist/yearlist_{magazineid}_{year}.txt”

    NSString *url=[NSString stringWithFormat:@"%@magazine/magazine_%@/yearlist/yearlist_%@_%@.txt",BUSSINESCACHESSERVER,ID,ID,year];


    [NSURLConnection sendAsynchronousRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]] queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {

        [SVProgressHUD dismiss];

        id root =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        success(root);

    }];


}
@end
