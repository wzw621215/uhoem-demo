//
//  LeftCollectionViewCell.m
//  MagookReader
//
//  Created by tailhuang on 15/9/22.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "LeftCollectionViewCell.h"
#import "MGIssueModel.h"
#import "UIButton+WebCache.h"
#import "MGLibHandle.h"
@interface LeftCollectionViewCell()

@property (weak, nonatomic) IBOutlet UIButton *coverButton;
@property (weak, nonatomic) IBOutlet UILabel *titleLab;

@end
@implementation LeftCollectionViewCell
- (IBAction)coverButtonClick:(id)sender {

    NSLog(@"LeftCollectionViewCell---跳到阅读");
    

    POSTER(GoToReadingFromBeforeNotification, self.model);
}
- (void)awakeFromNib {
    
    if (iPad) {
        self.titleLab.font=FONTIPAD;
    }
    
}
-(void)setModel:(MGIssueModel *)model{
    _model=model;

    [MGLibHandle getMGListCoverWithPath:model.path magezineID:model.magazineid issueid:model.issueid completionHandler:^(NSString *url) {
        //        NSLog(@"%@",url);
        [self.coverButton sd_setBackgroundImageWithURL:[NSURL URLWithString:url] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"封面"]];

    }];


    self.titleLab.text=model.issuename;
}

@end
