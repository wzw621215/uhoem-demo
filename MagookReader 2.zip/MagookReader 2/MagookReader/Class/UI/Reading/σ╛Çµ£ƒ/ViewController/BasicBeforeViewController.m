//
//  BeforeViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/20.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicBeforeViewController.h"
#import "BeforeHandle.h"
#import "MGIssueModel.h"
#import "YearModel.h"
#import "RightViewController.h"
#import "LeftViewController.h"
@interface BasicBeforeViewController ()
{
    NSInteger _total;

}
@property (nonatomic, strong) NSMutableDictionary *dataDic;
@property (nonatomic, strong) NSMutableArray *yearArray;
@property (nonatomic, strong) RightViewController *rightVC;
@property (nonatomic, strong) LeftViewController  *leftVC;
@end

@implementation BasicBeforeViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor=[UIColor whiteColor];

}

-(void)setModel:(MGIssueModel *)model{
    _model=model;

    self.yearArray=[NSMutableArray new];

    self.dataDic=[NSMutableDictionary new];
    _total=0;

    [BeforeHandle getYearListWithMgID:self.model.magazineid completeBlock:^(id responseObject) {

        for (NSDictionary *d in responseObject[@"data"]) {

            YearModel *m =[YearModel new];

            [m setValuesForKeysWithDictionary:d];

            _total += [m.count integerValue];

            [self.yearArray addObject:m];
        }

        [self createRightView];

        //首次进入，直接加载第一页,将数组
        [BeforeHandle getDetailListWithMgID:self.model.magazineid atYear:[responseObject[@"data"][0] objectForKey:@"year"] completeBlock:^(id responseObject) {

            NSMutableArray *array=[NSMutableArray new];
            for (NSDictionary *d in responseObject[@"data"]) {
                MGIssueModel *m=[MGIssueModel modelWithDic:d];
                m.magazineid=self.model.magazineid;
                m.magazinename=self.model.magazinename;

                [array addObject:m];
            }
            [self.dataDic setObject:array forKey:@"0"];

            [self createLeftView];
        }];

    }];

}
-(void)createRightView{
    self.rightVC =[RightViewController new];

    self.rightVC.total=_total;

    self.rightVC.dataArray=_yearArray;


    __weak typeof (self) weakSelf= self;

    self.rightVC.block=^(NSInteger selectedIndex){

        if ([[weakSelf.dataDic allKeys]containsObject:[NSString stringWithFormat:@"%ld",selectedIndex]]) {

            weakSelf.leftVC.dataArray=[weakSelf.dataDic objectForKey:[NSString stringWithFormat:@"%ld",selectedIndex]];
            return ;
        }
        YearModel *model = weakSelf.yearArray[selectedIndex];

        [BeforeHandle getDetailListWithMgID:weakSelf.model.magazineid atYear:model.year completeBlock:^(id responseObject) {

            NSMutableArray *array = [NSMutableArray new];
            for (NSDictionary *d in responseObject[@"data"]) {
                MGIssueModel *m=[MGIssueModel modelWithDic:d];
                m.magazineid=weakSelf.model.magazineid;
                m.magazinename=weakSelf.model.magazinename;
                [array addObject:m];
            }
            [weakSelf.dataDic setObject:array forKey:[NSString stringWithFormat:@"%ld",selectedIndex]];

            weakSelf.leftVC.dataArray=[weakSelf.dataDic objectForKey:[NSString stringWithFormat:@"%ld",selectedIndex]];
        }];

    };

    [self.view addSubview:self.rightVC.view];
    [self.rightVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(NAV_HEIGHT);
        make.right.equalTo(self.view);
        make.bottom.equalTo(self.view);
        make.width.mas_equalTo(RightTableW);
        
    }];

}
-(void)createLeftView{
    self.leftVC =[LeftViewController new];
    
    
    self.leftVC.dataArray=[NSMutableArray arrayWithArray:[self.dataDic objectForKey:@"0"]];
    
    [self.view addSubview:self.leftVC.view];
//    UIEdgeInsets padding = UIEdgeInsetsMake(NAV_HEIGHT, 0, 0, RightTableW);
    [self.leftVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view).with.insets(UIEdgeInsetsMake(NAV_HEIGHT, 0, 0, RightTableW));
    }];
    
}

@end
