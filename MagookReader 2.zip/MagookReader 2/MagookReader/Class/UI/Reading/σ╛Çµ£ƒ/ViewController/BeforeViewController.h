//
//  BeforeViewController.h
//  MagookReader
//
//  Created by tailhuang on 15/9/20.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicViewController.h"
@class MGIssueModel;
@interface BeforeViewController : BasicViewController
@property (nonatomic ,strong) MGIssueModel *model;
@property (nonatomic, copy)void (^block)(MGIssueModel *model);
@end
