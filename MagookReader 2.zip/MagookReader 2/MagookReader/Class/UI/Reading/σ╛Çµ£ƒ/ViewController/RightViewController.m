//
//  RightViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/22.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "RightViewController.h"
#import "YearModel.h"
#import "RightViewCell.h"
#import "NSAttributedString+ZBAttibutedSting.h"
@interface RightViewController ()
{
    NSInteger _selectedIndex;
}
@end

@implementation RightViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.scrollEnabled=YES;
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;

    _selectedIndex=0;
    self.view.backgroundColor=BKCOLOR;

    self.dataArray=[NSMutableArray new];

    self.tableView.tableFooterView=[[UIView alloc]init];



}
-(void)setTotal:(NSInteger)total{
    _total=total;
    WPHotspotLabel *titleLab = [[WPHotspotLabel alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
    titleLab.attributedText = [NSAttributedString stringWithText:[NSString stringWithFormat:@"共%ld期",_total] attributedString:[NSString stringWithFormat:@"%ld",_total] fontSize:16.0f color:COLOR block:^{

    }];

    titleLab.textAlignment=NSTextAlignmentCenter;
    titleLab.font=FONT;

    self.tableView.tableHeaderView=titleLab;

}
-(void)setDataArray:(NSMutableArray *)dataArray{
    _dataArray=dataArray;
    [self.tableView reloadData];
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {


    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.dataArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    static NSString *ID=@"yearCell";
    RightViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell= LOADNIBNAME(@"RightViewCell");
    }

    YearModel *model =self.dataArray[indexPath.row];
    
    cell.lab.text=[NSString stringWithFormat:@"%@年",model.year];





    cell.backgroundColor=BKCOLOR;

    cell.lab.textColor=[UIColor blackColor];
    if (indexPath.row==_selectedIndex) {
        cell.lab.textColor=COLOR;
        cell.backgroundColor=[UIColor whiteColor];
    }

    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    _selectedIndex=indexPath.row;
    if (self.block) {
        self.block(_selectedIndex);
    }
    [self.tableView reloadData];
}
@end
