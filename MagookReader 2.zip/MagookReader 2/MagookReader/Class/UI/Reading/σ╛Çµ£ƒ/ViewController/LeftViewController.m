
#import "LeftViewController.h"
#import "MGIssueModel.h"
#import "MGLibCell.h"
#import "LeftCollectionViewCell.h"
//#define  CELL_WIDTH  ITEM_WIDTH
//#define  CELL_HEIGHT (CELL_WIDTH/0.618)+40

@interface LeftViewController ()

@end

@implementation LeftViewController

static NSString * const reuseIdentifier = @"LeftViewCellID";

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor=[UIColor clearColor];


    //添加观察者
    OBSERVER(ShoppingCartDidChangeNotification,@selector(shoppingCartDidChange));

    UINib *cellNib = [UINib nibWithNibName:@"LeftCollectionViewCell" bundle:nil];
    [self.collectionView registerNib:cellNib forCellWithReuseIdentifier:reuseIdentifier];

    self.collectionView.showsHorizontalScrollIndicator=NO;
    self.collectionView.showsVerticalScrollIndicator=NO;

    self.collectionView.backgroundColor= BKCOLOR;

}

//销毁观察者
-(void)dealloc{
    REMOVEOBSERVER;
}
#pragma mark -监听购物车改变
-(void)shoppingCartDidChange{

    [self.collectionView reloadData];

}
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {

    return 1;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    return self.dataArray.count;
}


-(void)setDataArray:(NSMutableArray *)dataArray{
    _dataArray=dataArray;
    
    [self.collectionView reloadData];
    self.collectionView.contentOffset=CGPointZero;
//    [self.collectionView scrollsToTop];
//    [self.collectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UICollectionViewScrollPositionTop animated:NO];
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {

    LeftCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];

    //防崩溃保护
    if (self.dataArray.count) {
        cell.model=self.dataArray[indexPath.row];

    }

    //    cell.block=^(MGIssueModel *model){
    //

    //        self.block(model);
    //    };
    
    return cell;
}
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat labH=60;
    CGFloat itemPW = (MINSCREEN-RightTableW-ItemP*Margin)/(ItemP-1);
    CGFloat itemPH = itemPW/GoldenSection+labH;
    CGFloat itemLW = (MAXSCREEN-RightTableW-6*Margin)/ItemL;
    CGFloat itemLH = itemLW/GoldenSection+labH;
    CGSize size;
    
    if (PORTRAIT) {
        size=CGSizeMake(itemPW, itemPH) ;
    }else{
        size=CGSizeMake(itemLW, itemLH);
    }
    
    
    return size;
}

@end