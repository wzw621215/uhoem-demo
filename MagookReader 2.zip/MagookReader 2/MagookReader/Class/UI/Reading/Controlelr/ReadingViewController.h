//
//  ReadingViewController.h
//  MagookReader
//
//  Created by tailhuang on 15/9/16.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicViewController.h"
@class MGIssueModel;
@interface ReadingViewController : BasicViewController
@property (nonatomic, strong) MGIssueModel *model;

@end
