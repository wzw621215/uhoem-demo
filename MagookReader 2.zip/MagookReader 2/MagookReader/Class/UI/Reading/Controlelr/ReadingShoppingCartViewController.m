//
//  ReadingShoppingCartViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/21.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "ReadingShoppingCartViewController.h"

@interface ReadingShoppingCartViewController ()

@end

@implementation ReadingShoppingCartViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

-(BOOL)shouldAutorotate{
    
    return DOUBLEPAGE;
}


@end
