//
//  ContentViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/21.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "ContentViewController.h"
#import "ContentModel.h"
#import "DetailModel.h"
#import "MGIssueModel.h"
#import "ReadingHadle.h"
@interface ContentViewController ()
@property (nonatomic, strong) NSMutableArray *dataArray;
//目录的高度
//@property (nonatomic, assign) CGFloat height;
@end

@implementation ContentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.contentInset  = UIEdgeInsetsMake(10, 0, 0, 0);
    self.dataArray =[NSMutableArray new];
    //加载目录数据
    [ZBHud showActivityWithMessage:@"加载中"];
    [ReadingHadle getContentDataWithModel:self.model complete:^(NSDictionary *root) {
        [ZBHud dismiss];
        [ReadingHadle dataHandleWithDic:root finished:^(id obj) {

            self.dataArray=[NSMutableArray arrayWithArray:obj];
            [self.tableView reloadData];
        }];

    }];


}
//-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    return self.height+40;
//}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 20;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return self.dataArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [[self.dataArray[section] detailArray] count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    static NSString *ID =@"ContentCell";


    UITableViewCell *cell        = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }

    ContentModel *model          = self.dataArray [indexPath.section];
    DetailModel *m               = model.detailArray[indexPath.row];
    NSString *title= [NSString stringWithFormat:@"    %@",m.title];
    cell.textLabel.text          = title;
    cell.textLabel.font          = [UIFont systemFontOfSize:17];
    cell.textLabel.numberOfLines = 0;
    cell.textLabel.lineBreakMode = NSLineBreakByWordWrapping;
//    self.height=[m.title boundingRectWithSize:CGSizeMake(SCREEN_WIDTH-20*2-30, MAXFLOAT) options:NSStringDrawingUsesFontLeading|NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:FONT} context:nil].size.height;
//    NSLog(@"----%f",self.height);

    //设置页码
    UILabel *pageLab =[[UILabel alloc]init];
    pageLab.size                 = CGSizeMake(30, 30);
    pageLab.text=[m.page stringValue];
    pageLab.textColor            = COLOR;
    pageLab.font                 = [UIFont systemFontOfSize:14];
    pageLab.textAlignment        = NSTextAlignmentRight;


    cell.accessoryView           = pageLab;


    return cell;
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return [self.dataArray[section] title];
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    ContentModel *model          = self.dataArray [indexPath.section];
    DetailModel *m               = model.detailArray[indexPath.row];
    NSNumber *page               = m.page;

    [LogManager logWithViewID:self.viewID action:@"menu_click"];
    //回调
    self.block([page integerValue]);
    [self.navigationController popViewControllerAnimated:YES];
}
-(BOOL)shouldAutorotate{

    return DOUBLEPAGE;
}

@end
