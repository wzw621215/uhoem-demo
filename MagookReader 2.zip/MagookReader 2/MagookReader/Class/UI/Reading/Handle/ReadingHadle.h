//
//  ReadingHadle.h
//  MagookReader
//
//  Created by tailhuang on 15/9/20.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>
@class MGIssueModel;
typedef void(^complete)(id obj);
typedef void(^finish)(NSString *pageHashN,NSArray *titleArray);
@interface ReadingHadle : NSObject
+(NSString *)getSmallUrlAtPage:(NSInteger )page WithModel:(MGIssueModel *)model;
+(NSString *)getBigUrlAtPage:(NSInteger )page WithModel:(MGIssueModel *)model;
//获取目录数据
+(void)getContentDataWithModel:(MGIssueModel *)model complete:(complete)complete;
+(void)dataHandleWithDic:(NSDictionary *)root finished:(complete)finished;
+(void)getPageHashWithModel:(MGIssueModel *)model currentPage:(NSInteger)page finish:(finish)finish;
@end
