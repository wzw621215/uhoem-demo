//
//  ReadingCollectionViewCell.h
//  MagookReader
//
//  Created by tailhuang on 15/9/20.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MGIssueModel;

@interface ReadingCollectionViewCell : UICollectionViewCell

@property (nonatomic, copy)  void (^addToShoppingCartBlock)();
@property (nonatomic, strong)MGIssueModel *model;
-(void)configCellWithCurrentPage:(NSInteger)page model:(MGIssueModel *)model;

@end
