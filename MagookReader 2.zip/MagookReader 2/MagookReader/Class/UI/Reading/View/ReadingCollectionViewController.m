//
//  ReadingCollectionViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/17.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "ReadingCollectionViewController.h"
#import "ReadingCollectionViewCell.h"
#import "MGIssueModel.h"
#import "NSAttributedString+ZBAttibutedSting.h"
#import "DXAlertView.h"
#import "OMGToast.h"
#import "ReadingLandscapeCell.h"
@interface ReadingCollectionViewController ()
{
    WPHotspotLabel *_pageLab;

}

@property (nonatomic, assign) UserPermissionStyle permission;
@property (nonatomic ,assign) NSInteger currentPage;
@end

@implementation ReadingCollectionViewController

static NSString * const reuseIdentifier1 = @"ReadingCell";
static NSString * const reuseIdentifier2 = @"ReadingLandscapeCell";
- (void)viewDidLoad {
    [super viewDidLoad];
    self.collectionView.pagingEnabled=YES;
    self.collectionView.backgroundColor=[UIColor whiteColor];
    self.collectionView.bounces=NO;
    self.collectionView.showsHorizontalScrollIndicator = NO;
    self.collectionView.showsVerticalScrollIndicator = NO;
    self.automaticallyAdjustsScrollViewInsets=NO;

//    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:reuseIdentifier];

    UINib *xib1 = [UINib nibWithNibName:@"ReadingCollectionViewCell" bundle:nil];

    [self.collectionView registerNib:xib1 forCellWithReuseIdentifier:reuseIdentifier1];
    
    UINib *xib2 = [UINib nibWithNibName:@"ReadingLandscapeCell" bundle:nil];
    
    [self.collectionView registerNib:xib2 forCellWithReuseIdentifier:reuseIdentifier2];

}

-(void)orientationDidChange{

    //转之前是竖屏
     NSInteger page;
//    NSLog(@"currentPage=====%d",self.currentPage);
    if (UIDeviceOrientationIsLandscape([UIDevice currentDevice].orientation)) {
        //转之后是横屏
//        NSLog(@"横屏");
        self.collectionView.contentOffset=CGPointMake(self.currentPage/2*MAXSCREEN, 0);
        page=(self.currentPage+2)/2*2;
    }else{
//        NSLog(@"竖屏");

        page=self.currentPage+1;
        self.collectionView.contentOffset=CGPointMake(self.currentPage*MINSCREEN, 0);
    }

    _pageLab.attributedText = [NSAttributedString stringWithText:[NSString stringWithFormat:@"%@/%@",[NSNumber numberWithInteger:page],self.model.count] attributedString:[NSString stringWithFormat:@"%@",[NSNumber numberWithInteger:page]] fontSize:16.0f color:COLOR block:^{
    }];
    [self.collectionView reloadData];
}
-(instancetype)init{
    UICollectionViewFlowLayout*layout=[[UICollectionViewFlowLayout alloc]init];
    [layout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
    // 垂直间距
    layout.minimumLineSpacing = 0;
    // 水平间距
    layout.minimumInteritemSpacing = 0;
    // 内边距
    layout.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0);
    return [super initWithCollectionViewLayout:layout];
}


- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {

    return 1;
}
#pragma mark - model 的set方法
-(void)setModel:(MGIssueModel *)model{

    _model=model;
    //如果已购买，修改model的start和toll
    self.permission=[AppController checkPermissionWithMagazineID:self.model.magazineid];

    [self createPageLab];
    [self.collectionView reloadData];

}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    NSInteger count =[self.model.count integerValue];
    NSInteger toll = [self.model.toll integerValue];
    
    NSInteger tollPage =self.permission==UserPermissionStylePurchased?count:toll;
    if (PORTRAIT||!DOUBLEPAGE) {

        return tollPage;
    }else{

        return tollPage%2?(tollPage/2+1):(tollPage/2);
    }
    
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {

    if (PORTRAIT||!DOUBLEPAGE) {
   
        ReadingCollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier1 forIndexPath:indexPath];
        
        [cell configCellWithCurrentPage:indexPath.row model:self.model];

        cell.addToShoppingCartBlock=^{
            if (self.addToShoppingCartBlock) {
                self.addToShoppingCartBlock();
            }
        };
        return cell;
    }else{
        ReadingLandscapeCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier2 forIndexPath:indexPath];
        
        [cell configCellWithModel:self.model index:indexPath.row];
        
        cell.addToShoppingCartBlock=^{
            if (self.addToShoppingCartBlock) {
                self.addToShoppingCartBlock();
            }
        };
        return cell;
    }
}
-(void)setPage:(NSInteger)page{
    
    NSInteger startPage =[self.model.start integerValue];
    NSInteger tollPage =[self.model.toll integerValue];
    NSInteger count =[self.model.count integerValue];
    NSInteger maxPage =self.permission==UserPermissionStylePurchased?count: tollPage;

    NSInteger actualPage;
    if(page<=maxPage){

        actualPage=page+startPage;

    }else{
        actualPage=maxPage;

    }

    self.currentPage=actualPage-1;
    if (PORTRAIT) {
        NSLog(@"currentPage===竖屏==%ld",self.currentPage);
        self.collectionView.contentOffset=CGPointMake(self.currentPage*MINSCREEN, 0);
        actualPage=self.currentPage+1;
    }else{
    
        NSLog(@"currentPage===横屏==%ld",self.currentPage);
        self.collectionView.contentOffset=CGPointMake(self.currentPage/2*MAXSCREEN, 0);
        actualPage=(self.currentPage+2)/2*2;
    }
    NSLog(@"page--%ld---start--%ld---toll--%ld---max----%ld----actual----%d---self.currentPage---%d",page,startPage,tollPage,maxPage,actualPage, self.currentPage);

    _pageLab.attributedText = [NSAttributedString stringWithText:[NSString stringWithFormat:@"%@/%@",[NSNumber numberWithInteger:actualPage],self.model.count] attributedString:[NSString stringWithFormat:@"%@",[NSNumber numberWithInteger:actualPage]] fontSize:16.0f color:COLOR block:^{

    }];
    
    if (self.pageBlock) {
        self.pageBlock(page);
        
    }
}

-(void)createPageLab{

    if (!_pageLab) {
        _pageLab= [[WPHotspotLabel alloc]init];
        _pageLab.textAlignment=NSTextAlignmentRight;
        _pageLab.font=FONT;

        [self.view addSubview:_pageLab];
        [_pageLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.view).with.offset(-20);
            make.bottom.equalTo(self.view).with.offset(-10);
            make.left.equalTo(self.view);
            make.height.mas_equalTo(20);
        }];
    }

    NSInteger start;
    if (PORTRAIT||!DOUBLEPAGE) {
        start=1;
    }else{
        start=2;
    }

    _pageLab.attributedText = [NSAttributedString stringWithText:[NSString stringWithFormat:@"%ld/%@",start,self.model.count] attributedString:[NSString stringWithFormat:@"%ld",start] fontSize:16.0f color:COLOR block:^{

    }];

}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{

    //转之后是竖屏
    if (PORTRAIT) {
        self.currentPage=(NSInteger)scrollView.contentOffset.x/MINSCREEN;
    }else{
        
        if (!DOUBLEPAGE) {
            self.currentPage=(NSInteger)scrollView.contentOffset.x/MAXSCREEN;
        }else{
            self.currentPage=(NSInteger)scrollView.contentOffset.x/MAXSCREEN*2;
        }
    }

    NSInteger page;
    if (PORTRAIT||!DOUBLEPAGE) {
        page=self.currentPage+1;
    }else{
        page=self.currentPage+2;
    }
    if (self.pageBlock) {
        self.pageBlock(page);
    }
    _pageLab.attributedText = [NSAttributedString stringWithText:[NSString stringWithFormat:@"%ld/%@",page,self.model.count] attributedString:[NSString stringWithFormat:@"%ld",page] fontSize:16.0f color:COLOR block:^{
        
            }];
    
}

#pragma mark - 首尾提示控制
-(void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset{
    //记录上个x
    static CGFloat x ;
    //取出contentoffset
    CGPoint contetOffSet=*targetContentOffset;

//    NSLog(@"----%@---%@---%f---%f",NSStringFromCGPoint(velocity),NSStringFromCGPoint(*targetContentOffset),contetOffSet.x,SCREEN_WIDTH*([self.model.toll integerValue]-1));
//

//NSLog(@"%ld-----%f---%f---%f---%f",[self.model.toll integerValue]-1,velocity.x,x,contetOffSet.x);

    //向右滑动
    if (contetOffSet.x==0&&(velocity.x<0)&&x==contetOffSet.x) {
        NSLog(@"首页右滑,弹出已经是第一页");

        [OMGToast showWithText:@"已经是第一页了哦"];

    }
    NSInteger limitedMax;
    self.permission==UserPermissionStylePurchased?limitedMax=[self.model.count integerValue]:[self.model.toll integerValue];
    if ((contetOffSet.x==SCREEN_WIDTH*(limitedMax-1))&&(velocity.x>0)&&x==contetOffSet.x) {

        NSLog(@"尾页左滑,弹出温馨提示");


//        NSLog(@"%ld-----%f---%f---%f---%f",[self.model.toll integerValue]-1,velocity.x,x,contetOffSet.x);
        if (self.permission==UserPermissionStylePurchased) {
            //已购买
            [OMGToast showWithText:@"已经是最后一页了哦"];

        }else{
            //未购买或已过期
            DXAlertView *alert = [[DXAlertView alloc] initWithTitle:@"温馨提示" contentText:@"购买30元包年套餐即可享受\n多设备云阅读\n精彩往期杂志随意看\n下载到本地随意看" leftButtonTitle:@"取消" rightButtonTitle:@"加入购物车"];

            [alert show];

            [LogManager logWithViewID:self.viewID action:@"read_buy"];
            alert.leftBlock = ^() {
                NSLog(@"取消");
                [LogManager logWithViewID:self.viewID action:@"read_buy_cancel"];
            };
            alert.rightBlock = ^() {
                NSLog(@"确定");
                //回调
                if (self.addToShoppingCartBlock) {
                    self.addToShoppingCartBlock();
                }

            };
            alert.dismissBlock = ^() {
                NSLog(@"关闭");
            };
        }
    }

    //记录当前X
    x=contetOffSet.x;
    
}
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
    CGFloat itemPW = MINSCREEN;
    CGFloat itemPH = MAXSCREEN;
    CGFloat itemLW = MAXSCREEN;
    CGFloat itemLH = MINSCREEN;
    CGSize size;
    
    if (PORTRAIT) {
//        NSLog(@"竖屏");
        size=CGSizeMake(itemPW, itemPH) ;
    }else{
//        NSLog(@"横屏");
        size=CGSizeMake(itemLW, itemLH);
    }
    
    
    return size;
}

@end
