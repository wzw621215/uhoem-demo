//
//  ReadingCollectionViewCell.m
//  MagookReader
//
//  Created by tailhuang on 15/9/20.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "ReadingCollectionViewCell.h"
#import "PageView.h"
#import "MGIssueModel.h"
#import "ReadingHadle.h"
#import "UIImageView+Extension.h"
#import "UIImage+WebP.h"
#import "DXAlertView.h"
//#import "SVProgressHUD.h"
#import "ZBActivity.h"

@interface ReadingCollectionViewCell()
@property (weak, nonatomic) IBOutlet PageView *pageView;


@end
@implementation ReadingCollectionViewCell
-(instancetype)initWithCoder:(NSCoder *)aDecoder{
    if (self=[super initWithCoder:aDecoder]) {
        self.backgroundColor=[UIColor clearColor];
        self.pageView.backgroundColor=[UIColor clearColor];
        UISwipeGestureRecognizer *left =[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(leftSwipe)];
    left.direction              = UISwipeGestureRecognizerDirectionLeft;
        [self addGestureRecognizer:left];
        UISwipeGestureRecognizer *right =[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(rightSwipe)];
    right.direction             = UISwipeGestureRecognizerDirectionRight;
        [self addGestureRecognizer:right];
    self.userInteractionEnabled = YES;
    }
    return self;
}
-(void)rightSwipe{
    NSLog(@"从左往右划");
}
-(void)leftSwipe{
    NSLog(@"从右向左划");

    UserPermissionStyle style = [AppController checkPermissionWithMagazineID:self.model.magazineid];
    if (style ==UserPermissionStyleDoNotPurchased) {
        DXAlertView *alert          = [[DXAlertView alloc] initWithTitle:@"温馨提示" contentText:@"购买30元包年套餐即可享受\n多设备云阅读\n精彩往期杂志随意看\n下载到本地随意看" leftButtonTitle:@"取消" rightButtonTitle:@"加入购物车"];
        
        [alert show];
        
        alert.leftBlock             = ^() {
            NSLog(@"取消");
        };
        alert.rightBlock            = ^() {
            NSLog(@"确定");
            //回调
            if (self.addToShoppingCartBlock) {
                self.addToShoppingCartBlock();
            }
            
        };
        alert.dismissBlock          = ^() {
            NSLog(@"关闭");
        };
    }
}
-(void)configCellWithCurrentPage:(NSInteger)page model:(MGIssueModel *)model{

    _model=model;
    if (page<model.downloadedNumber) {
//        NSLog(@"读取缓存图片");
        [self.pageView.imageView setImage:[UIImage imageNamed:@"封面"]];
        NSString *filePath=[DOCUMENTSPATH stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@_%@/%@.png",DownloadDirectoryName,model.magazinename,model.issuename,[NSNumber numberWithInteger:page+1]]];
        
        [self.pageView.imageView setImage:[UIImage imageWithContentsOfFile:filePath]];

    }else{
//        NSLog(@"网络加载图片");
            NSString *smUrl=[ReadingHadle getSmallUrlAtPage:page+1 WithModel:model];
            NSString *bigUrl=[ReadingHadle getBigUrlAtPage:page +1 WithModel:model];
//        NSLog(@"bigUrl======%@",bigUrl);
        [ZBActivity showActivityInView:self.contentView];
        
        
            [self.pageView.imageView loadImageWithSmallImage:smUrl bigImage:bigUrl progress:^(NSInteger receivedSize, NSInteger expectedSize) {//大图片进度
            } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {

                [LogManager logWithViewID:@11 action:@"read_page" info:[NSString stringWithFormat:@"%@;%@;%ld",model.magazineid,model.issueid,page +[model.start integerValue]]];
                [ZBActivity dismiss];
            }];

    }
}
//-(void)imageWithFile:(NSString *)filePath complete:(void (^)(UIImage *image))complete{
//    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
//
//        UIImage *image=[UIImage sd_imageWithWebPData:[NSData dataWithContentsOfFile:filePath options:NSDataReadingMappedIfSafe error:nil]];
//
//        dispatch_async(dispatch_get_main_queue(), ^{
//            
//            if (image) {
//                complete(image);
//            }
//        });
//    });
//}

@end
