//
//  RecentCell.h
//  MagookReader
//
//  Created by tailhuang on 15/10/14.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MGIssueModel;
@interface RecentCell : UICollectionViewCell
@property (nonatomic, strong) MGIssueModel *model;

@end
