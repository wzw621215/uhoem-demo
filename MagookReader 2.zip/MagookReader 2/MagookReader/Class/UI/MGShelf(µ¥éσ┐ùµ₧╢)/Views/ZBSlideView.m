//
//  ZBSlideView.m
//  MagookReader
//
//  Created by tailhuang on 15/9/11.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "ZBSlideView.h"

@interface ZBSlideView()<UIScrollViewDelegate>
{
    UIView *_line;

    UIScrollView *_sC;
    NSInteger _currentPage;

}
@end
@implementation ZBSlideView
-(instancetype)initWithFrame:(CGRect)frame{


    if (self= [super initWithFrame:frame]) {


    }
    return self;
}

-(void)createView{

    //背景图

    self.backgroundColor=BKCOLOR;


    //两个按钮及绿色线条

    [self creatButtons];

    [self createSC];


}
-(void)setViewControllers:(NSArray *)viewControllers{

    _viewControllers = viewControllers;

    [self createView];


}

//封装创建按钮的方法
-(void)creatButtons{


    CGFloat btnWith = self.width/self.viewControllers.count;

    CGFloat btnHeight = 30.0;

    NSMutableArray*titleArray =[[NSMutableArray alloc]init];


    for (UIViewController*vc in self.viewControllers) {
        [titleArray addObject:vc.title];
    }
    
    for (int i=0; i<self.viewControllers.count; i++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];

        button.frame = CGRectMake(btnWith*i, 0, btnWith, btnHeight);
        button.backgroundColor=BKCOLOR;

        button.tag = 1000+i;

        [button setTitle:titleArray[i] forState:UIControlStateNormal];

        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

        [button setTitleColor:self.themeColor forState:UIControlStateSelected];

        button.titleLabel.font = [UIFont systemFontOfSize:15.0f];

        if (button.tag == 1000) {

            button.selected = YES;
        }
        [button addTarget:self action:@selector(topButtonClick:) forControlEvents:UIControlEventTouchUpInside];

        [self addSubview:button];
        
    }


    //绿色的线条
    _line = [[UIView alloc]init];
    
    _line.backgroundColor=self.themeColor;
    [self addSubview:_line];


}
-(void)topButtonClick:(UIButton *)btn{

    [self endEditing:YES];

    for (int i= 0; i <self.viewControllers.count; i++) {
        UIButton *button  = (UIButton *)[self viewWithTag:1000+i];

        if (btn.tag == 1000+i) {
            button.selected=YES;

            //取消动画
//            [UIView animateWithDuration:0.3 animations:^{
                _sC.contentOffset = CGPointMake(_sC.width*i, 0);
//            }];

        }else{
            button.selected=NO;
        }
    }

    [UIView animateWithDuration:0.3 animations:^{

        _line.x = btn.x;
    }];

}
-(void)layoutSubviews{
    [super layoutSubviews];

    _sC.pagingEnabled=YES;
    
    CGFloat btnWith = self.width/self.viewControllers.count;
    
    CGFloat btnHeight = 30.0;

    _sC.frame=CGRectMake(0, 35, self.width, self.height-35);
    _sC.contentSize   = CGSizeMake(_sC.width*self.viewControllers.count, _sC.height);

    for (int i=0; i<self.viewControllers.count; i++) {
        UIButton *button=[self viewWithTag:1000+i];
        button.frame = CGRectMake(btnWith*i, 0, btnWith, btnHeight);
    }


    for (int i=0; i<self.viewControllers.count; i++) {
        UIView *view=_sC.subviews[i];

        
        view.frame=CGRectMake(_sC.width*i, 0, _sC.width, _sC.height);

    };


    _sC.contentOffset=CGPointMake(self.width*_currentPage, 0);
    _line.frame=CGRectMake(btnWith*_currentPage, 32, btnWith, 3);

    
}

-(void)createSC{

    _sC = [[UIScrollView alloc]init];

    _sC.pagingEnabled = YES;

    _sC.showsHorizontalScrollIndicator = NO;
    _sC.delegate = self;


    
    for (int i =0; i<self.viewControllers.count; i++) {
        UIViewController*vc = self.viewControllers[i];


        [_sC addSubview:vc.view];
    }
    
    [self addSubview:_sC];

}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{

    POSTER(ZBSlideViewDidScrollNotification, @(scrollView.contentOffset.x/SCREEN_WIDTH));


    _line.x = _sC.contentOffset.x/self.viewControllers.count;
    
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    NSInteger index = _sC.contentOffset.x/_sC.width;
    
    for (int i =0; i<self.viewControllers.count; i++) {
        UIButton *button = (UIButton *)[self viewWithTag:1000+i];
        if (index == i) {
            button.selected=YES;
        }else{
            button.selected=NO;
        }
        
    }
    _currentPage=_sC.contentOffset.x/self.width;

    
}



@end
