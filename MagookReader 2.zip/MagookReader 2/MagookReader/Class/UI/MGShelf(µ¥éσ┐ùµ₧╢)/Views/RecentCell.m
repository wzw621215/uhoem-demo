
//
//  RecentCell.m
//  MagookReader
//
//  Created by tailhuang on 15/10/14.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "RecentCell.h"
#import "UIImage+WebP.h"
#import "MGLibHandle.h"
#import "MGIssueModel.h"
#import "UIButton+WebCache.h"
@interface RecentCell ()
@property (weak, nonatomic) IBOutlet UIButton *coverButton;
@property (weak, nonatomic) IBOutlet UILabel *nameLab;
@property (weak, nonatomic) IBOutlet UILabel *issueLab;

@end
@implementation RecentCell
-(void)awakeFromNib{
    if (iPad) {
        self.nameLab.font=FONTIPAD;
        self.issueLab.font=FONTIPAD;
    }
}
- (IBAction)coverButtonClick:(id)sender {
    POSTER(GoToReadingFromMGShelfNotification, self.model);
}

-(void)setModel:(MGIssueModel *)model{
    _model             = model;

//    if (model.downloadedNumber>0) {
//
//        NSString *documents=[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
//        NSString *filePath=[documents stringByAppendingPathComponent:[NSString stringWithFormat:@"Download/%@_%@/1.mg",model.magazinename,model.issuename]];
//
//        UIImage *image =[UIImage imageWithWebP:filePath];
//        [self.coverButton setImage:image forState:UIControlStateNormal];
//
//    }else{

        [MGLibHandle getMGListCoverWithPath:model.path magezineID:model.magazineid issueid:model.issueid completionHandler:^(NSString *url) {


            [self.coverButton sd_setImageWithURL:[NSURL URLWithString:url] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"封面"]];
        }];

//    }
    self.nameLab.text  = model.magazinename;
    self.issueLab.text = model.issuename;


}

@end
