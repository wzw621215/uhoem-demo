//
//  MGShelfHandle.m
//  MagookReader
//
//  Created by tailhuang on 15/10/13.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "MGShelfHandle.h"
#import "PurchasedModel.h"
#import "AFNetworking.h"
#import "JSONKit.h"
#import "MGIssueModel.h"
#import "MJExtension.h"
@implementation MGShelfHandle
+(void)getPurchasedDataComplete:(Complete)complete{

    UserModel *user =[UserModel sharedUser];
    NSString *url=[NSString stringWithFormat:@"%@user/role",IDSSERVER];
    if (user.usertoken==nil&&!INREVIEW) {
        NSLog(@"用户未登录，不刷新数据");
        complete(nil);
        return;
    }
    NSDictionary *param =@{
                           @"userid":user.userid,
                           @"userhash":user.userHash,
                           @"usertoken":INREVIEW?@"inReview":user.usertoken,
                           @"device":DEVICE
                           };
//    NSLog(@"刷新已购买----->%@",url);
//    NSLog(@"刷新已购买----->%@",[param JSONString]);
    [NSOperation POST:url parameters:param success:^(AFHTTPRequestOperation *operation, id responseObject) {

//    NSLog(@"刷新已购买----->%@",[responseObject JSONString]);
        if (responseObject==nil) {
            NSLog(@"获取已购买失败");
            complete(nil);
            return ;
        }
        if ([responseObject[@"iswholelib"] isEqualToNumber:@1]) {
            NSLog(@"获取已购买---全库Vip");
            user.iswholelib=@1;
            user.wholelibexpiredate=responseObject[@"wholelibexpiredate"];
        }else{
            NSLog(@"获取已购买---非全库Vip");
            user.iswholelib=@0;
        }
            NSArray *dataArray=responseObject[@"data"];
            user.puchasedArray=[PurchasedModel objectArrayWithKeyValuesArray:dataArray];
            if (dataArray.count) {
                NSArray *magazineidArray=[dataArray valueForKeyPath:@"magazineid"];
                [self getMagazinedataWithArray:magazineidArray Complete:^(NSArray *array) {
                complete(array);
                }];
            }else{
                complete(dataArray);
            }

    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"刷新已购买失败");
        [ZBHud showErrorWithMessage:@"已购买数据加载失败!"];
        complete(nil);
        
    }];
    
}
+(void)getMagazinedataWithArray:(NSArray *)magazineidArray Complete:(Complete)complete{

    //    url=”{businessServer}/magazine/magazinedata”
    
    NSString *url =[NSString stringWithFormat:@"%@magazine/magazinedata",BUSSINESSSERVER
                    ];

    NSMutableArray *query=[NSMutableArray new];
    
    for (NSNumber *magazineid in magazineidArray) {
         NSDictionary *queryDic=@{@"magazineid":magazineid,
                   @"issueindexstart":@0,
                   @"issuenumber":@1
                   };
        
        [query addObject:queryDic];
    }
    

    
    NSDictionary *param =@{@"query":query,
                           @"orgid":@"magook",
                           @"device":DEVICE
                           };
    
    NSData *postData=[param JSONData];
    
    NSMutableURLRequest *request =[NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    request.timeoutInterval=TimeOutInterval;
    [request setValue:@"POST" forKey:@"HTTPMethod"];
    
    [request setHTTPBody: postData];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {
        
        if (data) {
            
            NSDictionary *root =[data objectFromJSONData];
            NSArray *rootArray=[root valueForKeyPath:@"data.issueinfo"];
            NSMutableArray *dataArray=[NSMutableArray new];
            for (NSArray *temp in rootArray) {
                MGIssueModel *model = [MGIssueModel objectWithKeyValues:temp[0]];
                [dataArray addObject:model];
            }
            complete(dataArray);

        }else{
            NSLog(@"connectionError---%@",connectionError.domain);
            complete(nil);
        }
        
    }];

}
+(void)getMagazinedataWithMagazineid:(NSNumber *)magazineid success:(Success)success{
//    url=”{businessServer}/magazine/magazinedata”

    NSString *url =[NSString stringWithFormat:@"%@magazine/magazinedata",BUSSINESSSERVER
                    ];
//    NSLog(@"%@",url);
    NSDictionary * queryDic=@{@"magazineid":magazineid,
                         @"issueindexstart":@0,
                             @"issuenumber":@1
                              };

    NSArray *query=@[queryDic];

    NSDictionary *param =@{@"query":query,
                           @"orgid":@"magook",
                          @"device":DEVICE
                           };

    NSData *postData=[param JSONData];

    NSMutableURLRequest *request =[NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];

    request.timeoutInterval=TimeOutInterval;
    [request setValue:@"POST" forKey:@"HTTPMethod"];

    [request setHTTPBody: postData];

    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {

        if (data) {
            NSDictionary *root =[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];

            if ([root objectForKey:@"data"]) {
                NSArray *dataArray=root[@"data"];
                NSDictionary *issueinfo =[dataArray firstObject];
                NSDictionary *d=[issueinfo[@"issueinfo"] firstObject];

                MGIssueModel *model = [MGIssueModel modelWithDic:d];

                //回调
                success(model);
            }
        }else{
            NSLog(@"connectionError---%@",connectionError.domain);
        }

    }];

}

@end
