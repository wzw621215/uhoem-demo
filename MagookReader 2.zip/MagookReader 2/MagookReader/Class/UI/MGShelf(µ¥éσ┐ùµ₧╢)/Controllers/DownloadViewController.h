//
//  CollectionViewController.h
//  edit
//
//  Created by tailhuang on 15/10/11.
//  Copyright © 2015年 magook.com. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import "BasicCollectionViewController.h"
@class MGIssueModel;

@interface DownloadViewController : BasicCollectionViewController

@property (nonatomic, strong) NSMutableArray *dataArray;
-(void)cofirmDelete;
-(void)beginEdit;
-(void)cancelDelete;
-(void)endEdit;
@end
