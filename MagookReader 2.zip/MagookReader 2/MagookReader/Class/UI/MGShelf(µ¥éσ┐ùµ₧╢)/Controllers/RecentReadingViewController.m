//
//  RecentReadingViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/11.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "RecentReadingViewController.h"
#import "DefaultPageView.h"
//#import "PurcharsedCell.h"
#import "RecentReadingDataManager.h"
#import "RecentCell.h"
#import "MJRefresh.h"

@interface RecentReadingViewController ()
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong)DefaultPageView *defaultPage;
@property (nonatomic, strong) RecentReadingDataManager *manager;
@property (nonatomic ,assign) NSInteger count;
@end

@implementation RecentReadingViewController
static NSString * const reuseIdentifier = @"RecentCell";
-(RecentReadingDataManager *)manager{
    if (!_manager) {
        _manager=[RecentReadingDataManager sharedManager];
    }
    return _manager;
}
-(void)viewWillAppear:(BOOL)animated{

    [super viewWillAppear:animated];
    
    if ([self.manager allData].count!=self.count) {
        [self.collectionView.header beginRefreshing];
    }

}
#pragma mark -清空最近阅读
-(void)cleanRecent{
    //清空数据源
    [LogManager logWithViewID:self.viewID action:@"history_clear"];
    
    [self.dataArray removeAllObjects];
    //清空数据库
    for (MGIssueModel *model in [self.manager allData]) {
        [self.manager deleteDataWithModel:model];
    }
    //刷新页面
        [self.collectionView reloadData];
    //加上默认页
    if (!_defaultPage) {
        [self.view addSubview:self.defaultPage];
    }


}

#pragma mark -懒加载defaultePage
-(DefaultPageView *)defaultPage{
    if (!_defaultPage) {
        _defaultPage= LOADNIBNAME(@"DefaultPageView");
        _defaultPage.frame=self.view.bounds;
        _defaultPage.defaultImageView.image=[UIImage imageNamed:@"杂志架_空"];
        _defaultPage.defaultLab.text=@"没有最近阅读的杂志";
    }
    return _defaultPage;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.dataArray=[NSMutableArray new];
    if (!_defaultPage) {
        [self.view addSubview:self.defaultPage];
    }
    OBSERVER(ZBSlideViewDidScrollNotification, @selector(ZBSlideViewDidScroll:));
    __weak __typeof(self) weakSelf = self;
    self.collectionView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [weakSelf refreshData];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf.collectionView.header endRefreshing];

        });
    }];
    //用户登出
    OBSERVER(LogOutNotification, @selector(userDidLogout));

    UINib *cellNib = [UINib nibWithNibName:@"RecentCell" bundle:nil];
    [self.collectionView registerNib:cellNib forCellWithReuseIdentifier:@"RecentCell"];

    self.collectionView.backgroundColor=BKCOLOR;
   
}
-(void)setDataArray:(NSMutableArray *)dataArray{
    _dataArray=dataArray;
    
    if (_dataArray.count) {
        if (_defaultPage) {
            [_defaultPage removeFromSuperview];
            _defaultPage=nil;
        }
        if (_dataArray.count!=self.count) {
            [self.collectionView.header beginRefreshing];
        }
        
        self.count=_dataArray.count;
    }else{
        [self.view addSubview:self.defaultPage];
    }
    
}
-(void)ZBSlideViewDidScroll:(NSNotification *)noti{

    if ([noti.object isEqualToNumber:@1]) {
        
        if ([self.manager allData].count!=self.count) {
            NSLog(@"刷新最近");
            [self.collectionView.header beginRefreshing];
        }
        
    }
}
-(void)refreshData{
    self.dataArray=[NSMutableArray arrayWithArray:[self.manager allData]];
    
    [self.collectionView reloadData];

}

-(void)userDidLogout{
    [self.dataArray removeAllObjects];
    [self.collectionView reloadData];

}
#pragma mark - 代理方法
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {

    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    return self.dataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {

    RecentCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];


    cell.model=self.dataArray[indexPath.row];


    
    return cell;
}
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat LabH =40;
    
    CGFloat PurchaseCellPW = (MINSCREEN-(ItemP+1)*Margin)/ItemP;
    CGFloat PurchaseCellPH = PurchaseCellPW/GoldenSection+LabH;
    CGFloat PurchaseCellLW = (MAXSCREEN-(ItemL+1)*Margin)/ItemL;
    CGFloat PurchaseCellLH = PurchaseCellLW/GoldenSection+LabH;
    CGSize size;
    if (UIInterfaceOrientationIsPortrait(self.interfaceOrientation)) {
        size=CGSizeMake(PurchaseCellPW, PurchaseCellPH);

    }else{

        size=CGSizeMake(PurchaseCellLW, PurchaseCellLH);

    }
    
    return size;
}

@end
