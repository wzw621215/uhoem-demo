//
//  PurchasedViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/11.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "PurchasedViewController.h"
#import "DefaultPageView.h"
#import "MGShelfHandle.h"
#import "SVProgressHUD.h"
#import "PurcharsedCell.h"
#import "MJRefresh.h"
#import "NewBonus.h"
#import "BonusHadle.h"
@interface PurchasedViewController ()
@property (nonatomic, strong)DefaultPageView *defaultPage;
@property (nonatomic, strong) NSMutableArray *dataArray;
@end

@implementation PurchasedViewController
static NSString * const reuseIdentifier = @"PurcharsedCell";

#pragma mark -懒加载defaultePage
-(DefaultPageView *)defaultPage{
    if (!_defaultPage) {
        _defaultPage                            = LOADNIBNAME(@"DefaultPageView");
        _defaultPage.frame                      = self.view.bounds;
        _defaultPage.defaultImageView.image=[UIImage imageNamed:@"杂志架_空"];
        _defaultPage.defaultLab.text=@"杂志架是空的";
    }
    return _defaultPage;
}
-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray=[NSMutableArray new];
    }
    return _dataArray;
}
- (void)viewDidLoad {

    [super viewDidLoad];

    [self becomeObserver];

    if (!_defaultPage) {
        [self.view addSubview:self.defaultPage];
    }
    __weak __typeof(self) weakSelf          = self;
    // 下拉刷新
    self.collectionView.header              = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [weakSelf refreshData];
        // 模拟延迟加载数据
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            // 结束刷新
            [weakSelf.collectionView.header endRefreshing];
        });
    }];
    self.collectionView.contentInset        = UIEdgeInsetsMake(0, 0, TAB_HEIGHT, 0);
    self.view.backgroundColor               = BKCOLOR;
    UINib *cellNib                          = [UINib nibWithNibName:@"PurcharsedCell" bundle:nil];
    [self.collectionView registerNib:cellNib forCellWithReuseIdentifier:@"PurcharsedCell"];
    self.collectionView.backgroundColor     = BKCOLOR;
    if ([UserModel sharedUser].usertoken||INREVIEW) {
    [self.collectionView.header beginRefreshing];
    }
}
-(void)becomeObserver{
    OBSERVER(FinishPayNotification, @selector(finishPay));
    OBSERVER(LogOutNotification, @selector(userDidLogout));
    OBSERVER(LoginSuccessNotification, @selector(LoginSuccess));
}

//登录成功之后刷新
-(void)LoginSuccess{
    [self.collectionView.header beginRefreshing];
}
-(void)userDidLogout{
    [self.dataArray removeAllObjects];
    [self.collectionView reloadData];
    [self.view addSubview:self.defaultPage];
    if (INREVIEW) {
        [self.collectionView.header beginRefreshing];
    }
}
-(void)finishPay{
    NSLog(@"finishPay");
    [self.collectionView.header beginRefreshing];
}

-(void)dealloc{
    REMOVEOBSERVER;
}

#pragma mark -刷新数据
-(void)refreshData{
    NSLog(@"刷新已购买");
        [MGShelfHandle getPurchasedDataComplete:^(NSArray *array) {
            //加载失败
            if (array==nil) {
                NSLog(@"已购买加载失败");
                [ZBHud showErrorWithMessage:@"已购买数据加载失败!"];
                if (!_defaultPage) {
                    [self.view addSubview:self.defaultPage];
                }
                return ;
            }
            //加载成功但数组为空
            if (array.count==0) {
                NSLog(@"已购买加载成功，无已购买数据");
                if (!_defaultPage) {
                    [self.view addSubview:self.defaultPage];
                }
            }else{
                if (_defaultPage) {
                    [_defaultPage removeFromSuperview];
                    _defaultPage                            = nil;
                }
            }
                self.dataArray=[NSMutableArray arrayWithArray:array];
                [self.collectionView reloadData];
        }];
}
#pragma mark - 代理方法
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat LabH                            = 20;
    CGFloat PurchaseCellPW                  = (MINSCREEN-(ItemP+1)*Margin)/ItemP;
    CGFloat PurchaseCellPH                  = PurchaseCellPW/GoldenSection+LabH;
    CGFloat PurchaseCellLW                  = (MAXSCREEN-(ItemL+1)*Margin)/ItemL;
    CGFloat PurchaseCellLH                  = PurchaseCellLW/GoldenSection+LabH;
    CGSize size;

    if (UIInterfaceOrientationIsPortrait(self.interfaceOrientation)) {
        size                                    = CGSizeMake(PurchaseCellPW, PurchaseCellPH);
    }else{
        size                                    = CGSizeMake(PurchaseCellLW, PurchaseCellLH);
    }
    return size;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    return self.dataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {

PurcharsedCell *cell                    = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];

    if (self.dataArray.count) {
cell.model                              = self.dataArray[indexPath.row];
    }


    return cell;
}


@end
