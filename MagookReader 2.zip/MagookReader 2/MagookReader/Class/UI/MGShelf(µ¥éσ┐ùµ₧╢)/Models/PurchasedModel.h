//
//  UserPermissionModel.h
//  MagookReader
//
//  Created by tailhuang on 15/10/12.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "BasicModel.h"
//已购买
@interface PurchasedModel : BasicModel
@property (nonatomic, strong) NSNumber *magazineid;
@property (nonatomic, strong) NSNumber *issueid;
@property (nonatomic, strong) NSNumber *sortid;
@property (nonatomic, strong) NSNumber *startdate;
@property (nonatomic, strong) NSNumber *starttime;
@property (nonatomic, strong) NSNumber *enddate;
@property (nonatomic, strong) NSNumber *endtime;


@end
