//
//  BonusHadle.m
//  MagookReader
//
//  Created by zhoubin on 15/10/24.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "BonusHadle.h"
#import "OrderHandle.h"
#import "MGShelfHandle.h"
#import "MGIssueModel.h"
@implementation BonusHadle
+(void)getBonusDataWithStatusfilter:(NSString *)statusfilter compete:(complete)complete{
//    url=”{purchaseserver}/bonus/getbonusbyuid”
    NSString *url =[NSString stringWithFormat:@"%@bonus/getbonusbyuid",PURCHASSERVER];
    NSDictionary *param=@{
                          @"userid":[UserModel sharedUser].userid,
                          @"userhash":[UserModel sharedUser].userHash,
                          @"usertoken":INREVIEW?@"":[UserModel sharedUser].usertoken,
                          @"statusfilter":statusfilter,
                          @"device":DEVICE
                          };
//    NSLog(@"%@",url);
//    NSLog(@"%@",[param JSONString]);
    [NSOperation POST:url parameters:param success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"获取红包成功");
        complete(responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [ZBHud showErrorWithMessage:@"获取红包数据失败"];
        complete(nil);
        NSLog(@"获取红包数据失败---%@",error);
    }];
}
+(void)getBonusHistoryDataFinish:(history)history{
    //从订单中筛选出已兑换的红包
    [OrderHandle getOrderDataFinish:^(id obj) {
        if([obj[@"status"] isEqualToNumber:@1]){
            NSArray *data=obj[@"data"];
            for (NSDictionary *dic in data) {
                //把错误数据过滤
                if ([dic[@"currency"] isKindOfClass:[NSNull class]]) {
                    continue;
                }
                if ([dic[@"currency"] isEqualToString:@"BONUS"]&&[dic[@"orderstatus"] isEqualToString:@"1"]) {
                    if ([(NSArray *)dic[@"magazineid"] count]) {
                        NSRange range=NSMakeRange(0, 10);
                        NSString *date=[dic[@"checkdate"] substringWithRange:range];
                        [MGShelfHandle getMagazinedataWithArray:dic[@"magazineid"] Complete:^(NSArray *array) {
                            history(array,date);
                        }];
//                    [MGShelfHandle getMagazinedataWithMagazineid:dic[@"magazineid"][0] success:^(MGIssueModel *model) {
//
//                        history(model,date);
//
//                        
//                    }];
                    }
                }
                
            }
        }else{
            history(nil,nil);
        }
        
    }];
}
@end
