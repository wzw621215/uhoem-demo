//
//  AboutViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/10.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "AboutViewController.h"
#import "UserSettingsHandle.h"
@interface AboutViewController ()

@end

@implementation AboutViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    if ([AppController sharedController].netWorkStatus) {
        UIWebView *web = [[UIWebView alloc]initWithFrame:self.view.bounds];
        [web loadRequest:[UserSettingsHandle aboutUsRequest]];
        [self.view addSubview:web];
        [web mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(UIEdgeInsetsMake(0, 0, 0, 0));
        }];
    }else{

        [ZBHud showErrorWithMessage:@"网络连接失败！"];
    }
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
