//
//  SearchHandle.m
//  MagookReader
//
//  Created by tailhuang on 15/9/16.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "SearchHandle.h"
#import "MGIssueModel.h"
#import "SVProgressHUD.h"
@implementation SearchHandle
+(void)searchWithString:(NSString *)string CompletionHandler:(void (^)(NSArray *))handler{
    [SVProgressHUD showWithStatus:@"加载中" maskType:SVProgressHUDMaskTypeClear];
    NSString *url=[NSString stringWithFormat:@"%@search/search",BUSSINESSSERVER];
    [LogManager logWithViewID:@9 action:@"search" info:string];
    /**
     *  {

     "userid":int,//

     "key":"string",//查询关键字

     "orgid": string, //

     "device":{device}
     
     }
     */
//    NSLog(@"%@",[UserModel sharedUser]);
    
    NSDictionary *param=@{
                          @"userid":[UserModel sharedUser].userid==nil?@"":[UserModel sharedUser].userid,
                          @"key":string,
                          @"orgid":@"magook",
                          @"device":DEVICE

                              };

[NSOperation POST:url parameters:param success:^(AFHTTPRequestOperation *operation, id responseObject) {
    if ([[responseObject objectForKey:@"status"] isEqualToNumber:@0]) {
        [SVProgressHUD showInfoWithStatus:responseObject[@"message"]];
        handler(nil);
    }else{

    NSMutableArray *array=[NSMutableArray new];
    for (NSDictionary *d in [responseObject objectForKey:@"data"]) {
        MGIssueModel *model =[MGIssueModel modelWithDic:d];

        [array addObject:model];
        [SVProgressHUD dismiss];
    }
    handler(array);
    }
    
} failure:^(AFHTTPRequestOperation *operation, NSError *error) {

    [SVProgressHUD dismiss];
    [ZBHud showErrorWithMessage:@"网络连接失败!"];
}];

}
@end
