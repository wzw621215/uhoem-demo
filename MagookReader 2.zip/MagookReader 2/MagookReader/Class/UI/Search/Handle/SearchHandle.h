//
//  SearchHandle.h
//  MagookReader
//
//  Created by tailhuang on 15/9/16.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SearchHandle : NSObject
+(void)searchWithString:(NSString *)string CompletionHandler:(void (^)( NSArray* array)) handler ;
@end
