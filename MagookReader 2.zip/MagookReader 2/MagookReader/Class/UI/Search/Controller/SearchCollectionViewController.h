//
//  CollectionViewController.h
//  MagookReader
//
//  Created by tailhuang on 15/9/16.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import "BasicCollectionViewController.h"
@class MGIssueModel;
@interface SearchCollectionViewController : BasicCollectionViewController
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, copy) void(^block)(MGIssueModel *);

@end
