//
//  SearchViewController.h
//  MagookReader
//
//  Created by tailhuang on 15/9/15.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicViewController.h"

@interface SearchViewController : BasicViewController
@property (nonatomic ,assign) BOOL isBonus;
@property (nonatomic ,assign) NSInteger bonusNumber;
@property (nonatomic ,strong) NSMutableDictionary *dataDic;
@end
