//
//  CollectionViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/16.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "SearchCollectionViewController.h"
#import "MGLibCell.h"

@interface SearchCollectionViewController ()

@end

@implementation SearchCollectionViewController

static NSString * const reuseIdentifier = @"MGlibCellID";

- (void)viewDidLoad {
    [super viewDidLoad];

    UINib *cellNib = [UINib nibWithNibName:@"MGLibCell" bundle:nil];
    [self.collectionView registerNib:cellNib forCellWithReuseIdentifier:reuseIdentifier];
    
    self.collectionView.showsHorizontalScrollIndicator=NO;
    self.collectionView.showsVerticalScrollIndicator=NO;

    self.collectionView.backgroundColor= BKCOLOR;
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {

    return 1;
}

-(void)setDataArray:(NSMutableArray *)dataArray{
    _dataArray=dataArray;
   [self.collectionView reloadData];
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _dataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {

        MGLibCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
        if (self.dataArray.count) {
            cell.model=self.dataArray[indexPath.row];
        }
        cell.block=^(MGIssueModel *model){
            self.block(model);
        };
        return cell;
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat LabH =60;
    
    CGFloat searchCellPW = (MINSCREEN-(ItemP+1)*Margin)/ItemP;
    CGFloat searchCellPH = searchCellPW/GoldenSection+LabH;
    CGFloat searchCellLW = (MAXSCREEN-(ItemL+1)*Margin)/ItemL;
    CGFloat searchCellLH = searchCellLW/GoldenSection+LabH;
    CGSize size;
    
    if (UIInterfaceOrientationIsPortrait([UIApplication sharedApplication].statusBarOrientation)) {
        size=CGSizeMake(searchCellPW, searchCellPH);
    }else{
        size=CGSizeMake(searchCellLW, searchCellLH);
    }
    return size;
}

@end
