//
//  BonusExchageCollectionView.h
//  MagookReader
//
//  Created by zhoubin on 15/10/24.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//


#import "BasicMGLibCollectionViewController.h"
@class LibDataModel,MGIssueModel;
@interface BonusExchageCollectionView : BasicMGLibCollectionViewController

@end
