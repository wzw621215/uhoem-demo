//
//  BonusExchageViewController.m
//  MagookReader
//
//  Created by zhoubin on 15/10/24.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "BonusExchageViewController.h"
#import "BonusExchageCollectionView.h"
#import "ExchangeRightViewController.h"
//#import "MGLibRightView.h"
#import "MGLibHandle.h"
#import "MGLibCell.h"
#import "MGIssueModel.h"
#import "CategoryModel.h"
#import "LibDataModel.h"
//#import "ReadingViewController.h"
#import "PayHandle.h"
#import "BonusHadle.h"
#import "ShoppingCartDataManager.h"
#import "ShoppingCartExChangeViewController.h"
#import "ZBScanManager.h"
#import "ScanHandle.h"
#import "BonusScanResultViewController.h"
#import "SearchViewController.h"
#import "MJExtension.h"
#define ARCHIVERPATH [CACHEPATH stringByAppendingPathComponent:MGLIBARCHIVER]
@interface BonusExchageViewController ()
@property (nonatomic, strong) ShoppingCartExChangeViewController *shopExVC;
//@property (nonatomic ,strong) BonusExchageCollectionView *collectionVC;
//@property (nonatomic ,strong) ExchangeRightViewController *rightVC;
//@property (nonatomic, strong) NSMutableDictionary *mainDataDic;
@property (nonatomic ,weak) UIButton *exchangeButton;
@property (nonatomic ,strong) NSMutableArray *bonusExchangeArray;
@property (nonatomic ,assign) NSNumber* total;
@property (nonatomic ,strong) NSMutableDictionary *dataDic;
@property (nonatomic ,strong) BonusScanResultViewController *scanVC;

@end

@implementation BonusExchageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    [self addObserver];

    OBSERVER(StepValueDidChageNotification, @selector(stepValueDidChange:));
    self.title=@"红包兑换";
    [self createTopView];
    [self createBottomView];
    [self createNavItems];
    
    if ([[ShoppingCartDataManager sharedManager]allData].count) {
        NSLog(@"购物车不为空，显示购物车兑换");
        
        [self createShopExVC];
    }else{
        NSLog(@"购物车为空,显示全部兑换");
        
    [self createRightViewWithVCClass:[ExchangeRightViewController class]];
    [self createCV];
    [self getOringinData];
    }
    
}
-(NSMutableDictionary *)dataDic{
    if (!_dataDic) {
        _dataDic=[NSMutableDictionary new];
    }
    return _dataDic;
}
-(void)createNavItems{
    UIBarButtonItem *scan=[UIBarButtonItem itemWithTarget:self action:@selector(scan) image:@"扫描" highImage:@"扫描_checked"];
    UIBarButtonItem *search=[UIBarButtonItem itemWithTarget:self action:@selector(search) image:@"搜索" highImage:@"搜索_checked"];
    self.navigationItem.rightBarButtonItems=@[search,scan];
}
#pragma  mark - 扫描
-(void)scan{
    NSLog(@"跳转扫描");
    [ZBScanManager scanInVC:self.navigationController complishBlock:^(NSString *url) {
        [ScanHandle handleUrl:url completedBlock:^(id root) {

            MGIssueModel *model =[MGIssueModel modelWithDic:[root[@"data"] firstObject]];
            //首先移除中间的部分
            if (_shopExVC) {
                [_shopExVC.view removeFromSuperview];
            }
            if (self.rightVC) {
                [self.rightVC.view removeFromSuperview];
            }
            if (self.collectionVC) {
                [self.collectionVC.view removeFromSuperview];
            }
            self.scanVC = [[BonusScanResultViewController alloc]init];
            self.scanVC.dataArray=[NSMutableArray arrayWithObject:model];
            self.scanVC.isLimited=[self.total integerValue]<self.bonusNumber;
            [self.view addSubview:self.scanVC.view];
            [self.scanVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
                make.edges.mas_equalTo(UIEdgeInsetsMake(NAV_HEIGHT+30, 0,TAB_HEIGHT , 0));
            }];
            
        }];
    }];
}
#pragma mark - 搜索
-(void)search{
    NSLog(@"跳转搜索");
    SearchViewController *vc= [SearchViewController new];
    vc.isBonus=YES;

    vc.bonusNumber=self.bonusNumber;
    vc.dataDic=self.dataDic;
    [self.navigationController pushViewController:vc animated:YES];
    
}
-(void)createShopExVC{
    self.shopExVC=[[ShoppingCartExChangeViewController alloc]init];

    [self.view addSubview:self.shopExVC.view];
    
    [self.shopExVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(UIEdgeInsetsMake(NAV_HEIGHT+30, 0,TAB_HEIGHT , 0));
    }];
    
    __weak typeof(self) weakSelf = self;
    self.shopExVC.plusBlock=^{

        [weakSelf.shopExVC.view removeFromSuperview];
        [weakSelf createTB];
        [weakSelf createCV];
        [weakSelf loadDataWithCategory:@0 Page:@1 finish:^(LibDataModel *libModel) {
            
        }];

        POSTER(LimitedStepNotification, [weakSelf.total integerValue]>=self.bonusNumber?@0:@1);
        
    };

}

#pragma mark -监听stepper数据
-(void)stepValueDidChange:(NSNotification *)not{
    NSLog(@"======================");
    NSInteger count =[not.userInfo[@"count"] integerValue];
    MGIssueModel *model=not.object;
    
    if (count>0) {
        NSDictionary *d=@{
                          @"magazineid":model.magazineid,
                          @"buypackageid":BUYPACKAGEBONUS,
                          @"quantity":[NSNumber numberWithInteger:count]
                          };
        [self.dataDic setValue:d forKey:[NSString stringWithFormat:@"%@",model.magazineid]];
    }else{
        if ([[self.dataDic allKeys] containsObject:[NSString stringWithFormat:@"%@",model.magazineid]]) {
            [self.dataDic removeObjectForKey:[NSString stringWithFormat:@"%@",model.magazineid]];
        }
    }
    int total=0;
    
    for (NSDictionary *d in [self.dataDic allValues]) {
        NSNumber *quantity=d[@"quantity"];
        total += [quantity integerValue];
    }
    NSLog(@"dataDic---------->%@",self.dataDic);
    self.bonusExchangeArray=[NSMutableArray arrayWithArray:[self.dataDic allValues]];
    self.total=@(total);
    if (total) {
        self.exchangeButton.enabled=YES;
        [self.exchangeButton setTitle:[NSString stringWithFormat:@"确认兑换（%@）",self.total] forState:UIControlStateNormal];
        self.exchangeButton.backgroundColor=[UIColor redColor];
    }else{
        self.exchangeButton.enabled=NO;
        self.exchangeButton.backgroundColor=RGB(200, 200, 200, 1);
    }

    POSTER(LimitedStepNotification, total>=self.bonusNumber?@0:@1);
    
}
#pragma mark - 兑换
-(void)exchangeButtonClick{

    [ZBHud showActivityWithMessage:@"正在提交订单"];
    //获取订单号
   
    NSDictionary *dic=[PayHandle commitBonusOrderWithMagdata:self.bonusExchangeArray ];
    NSString *orderNumber=dic[@"orderno"];
    
    //红包支付
    [PayHandle payBonusWithOrderNumber:orderNumber amount:self.total finish:^(id object) {
        
        //订单确认
        [PayHandle confirmOrderWithOdernumber:orderNumber complete:^(id obj) {
            
            NSNumber *finish=obj[@"data"][@"finish"];
            switch ([finish integerValue]) {
                case 0:
                    //支付未完成
                    [ZBHud showInfo:@"支付未完成"];
                    break;
                case 1:
                    //完成(iOS、麦豆支付)
                    [ZBHud showSuccessWithMessage:@"兑换成功"];
                    break;
                case 2:
                    //等待支付处理
                    [ZBHud showInfo:@"订单等待处理"];
                    break;
                    
                default:
                    break;
            }
            //兑换完毕直接返回首页
            [self.navigationController popToRootViewControllerAnimated:YES];
        }];

    }];
    
  }


-(void)createTopView{
    UIView *topView=[[UIView alloc]init];
    topView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:topView];
    [topView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).with.offset(NAV_HEIGHT);
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.height.mas_equalTo(30);
    }];
    CGFloat lab1W=100;
    
    UILabel *lab1=[[UILabel alloc]init];
    lab1.font=[UIFont systemFontOfSize:12];
    lab1.text=[NSString stringWithFormat:@"可兑换红包%ld个",self.bonusNumber];
    [topView addSubview:lab1];
    [lab1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(topView).with.offset(Margin);
        make.top.equalTo(topView);
        make.bottom.equalTo(topView);
        make.width.mas_equalTo(lab1W);
    }];

    
    UILabel *lab2=[[UILabel alloc]init];
    lab2.font=[UIFont systemFontOfSize:12];
    lab2.textColor=[UIColor redColor];
    lab2.textAlignment=NSTextAlignmentRight;
    lab2.text=@"注：一个红包可兑换一种杂志一周";
    [topView addSubview:lab2];
    [lab2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(UIEdgeInsetsMake(0, lab1W, 0, Margin));
    }];
}
-(void)createBottomView{
    UIButton *exchangeButton=[UIButton buttonWithType:UIButtonTypeCustom];
//    exchangeButton.frame=CGRectMake(0, SCREEN_HEIGHT-50, SCREEN_WIDTH, 50);
    exchangeButton.backgroundColor=RGB(200, 200, 200, 1);
    exchangeButton.enabled=NO;
    [exchangeButton setTitle:@"请选择要兑换的杂志" forState:UIControlStateDisabled];

    [exchangeButton addTarget:self action:@selector(exchangeButtonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:exchangeButton];
    self.exchangeButton=exchangeButton;
    
    [exchangeButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.bottom.equalTo(self.view);
        make.height.mas_equalTo(TAB_HEIGHT);
    }];
}
-(void)createCV{
    self.collectionVC=[[BonusExchageCollectionView alloc]init];

    self.collectionVC.bonusNumber=self.bonusNumber;
    self.collectionVC.isLimited=[self.total integerValue]<self.bonusNumber;
    [self.view addSubview:self.collectionVC.view];
    
    [self.collectionVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(UIEdgeInsetsMake(NAV_HEIGHT+30, 0,TAB_HEIGHT , RightTableW));
    }];
}
-(void)createTB{
    self.rightVC=[[ExchangeRightViewController alloc]initWithStyle:UITableViewStylePlain];

    __weak typeof(self) weakSelf=self;
    self.rightVC.block=^(NSInteger selectedIndex){
        
        if ([[weakSelf.mainDataDic allKeys]containsObject:[NSString stringWithFormat:@"%ld",selectedIndex]]) {
            
            weakSelf.collectionVC.model=[weakSelf.mainDataDic objectForKey:[NSString stringWithFormat:@"%ld",selectedIndex]];
            
        }else{
            //不存在则重新请求（请求完毕更新数据源）
            [weakSelf loadDataWithCategory:[NSNumber numberWithInteger:selectedIndex] Page:@1 finish:^(LibDataModel *libModel) {
            }];
        }
        //滚动到起始位置
        if (weakSelf.collectionVC.collectionView) {
            weakSelf.collectionVC.collectionView.contentOffset=CGPointZero;
        }
    };
    //传递数据
    [MGLibHandle getRightButtonTitlesCompletionHandler:^(id obj) {

        //用来存右侧标题模型的数组
        NSMutableArray *titleArray=[NSMutableArray new];
        titleArray=[CategoryModel objectArrayWithKeyValuesArray:obj[@"data"]];
        self.rightVC.dataArray=[NSMutableArray new];
        self.rightVC.dataArray=titleArray;
 
    }];

    [self.view addSubview:self.rightVC.view];
    [self.rightVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).with.offset(NAV_HEIGHT+30);
        make.right.equalTo(self.view);
        make.bottom.equalTo(self.view).with.offset(-TAB_HEIGHT);
        make.width.mas_equalTo(RightTableW);
    }];
}



@end
