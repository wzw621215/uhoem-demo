//
//  BonusExchageViewController.h
//  MagookReader
//
//  Created by zhoubin on 15/10/24.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

//#import "BasicViewController.h"
#import "BasicMGLibViewController.h"
@interface BonusExchageViewController : BasicMGLibViewController
@property (nonatomic ,assign) NSInteger bonusNumber;

@end
