//
//  ShoppingCartExChangeViewController.m
//  MagookReader
//
//  Created by zhoubin on 15/11/6.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "ShoppingCartExChangeViewController.h"
#import "ExchangeCell.h"
#import "MGIssueModel.h"
#import "ShoppingCartDataManager.h"


@interface ShoppingCartExChangeViewController()

@property (nonatomic ,strong) NSMutableArray *dataArray;

@end

@implementation ShoppingCartExChangeViewController

static NSString * const reuseIdentifier = @"ExchangeCell";

-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray=[NSMutableArray arrayWithArray:[[ShoppingCartDataManager sharedManager] allData]];
        
    }
    return _dataArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.collectionView.backgroundColor=BKCOLOR;
    UINib *cellNib = [UINib nibWithNibName:@"ExchangeCell" bundle:nil];
    [self.collectionView registerNib:cellNib forCellWithReuseIdentifier:reuseIdentifier];
}

-(void)dealloc{
    NSLog(@"销毁%@",[self class]);
    REMOVEOBSERVER;
}
#pragma mark - 代理方法
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    
    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return self.dataArray.count+1;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    
    ExchangeCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    
    //防崩溃保护
    if (self.dataArray.count) {
        if (indexPath.row==self.dataArray.count) {

            cell.stepper.hidden=YES;
            cell.cover.image=[UIImage imageNamed:@"add_img"];

            return cell;
        }
        cell.model=self.dataArray[indexPath.row];
    }
    
    return cell;
}
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat LabH =60;
    
    CGFloat itemPW = (MINSCREEN-(ItemP+1)*Margin)/ItemP;
    CGFloat itemPH = itemPW/GoldenSection+LabH;
    CGFloat itemLW = (MAXSCREEN-(ItemL+1)*Margin)/(ItemL);
    CGFloat itemLH = itemLW/GoldenSection+LabH;
    CGSize size;
    
    if (PORTRAIT) {
        size=CGSizeMake(itemPW, itemPH) ;
    }else{
        size=CGSizeMake(itemLW, itemLH);
    }

    return size;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==self.dataArray.count) {
        NSLog(@"点击加号");
        if (self.plusBlock) {
            self.plusBlock();
        }
    }
}
@end
