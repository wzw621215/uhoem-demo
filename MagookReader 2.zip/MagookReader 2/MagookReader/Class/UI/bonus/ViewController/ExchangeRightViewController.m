//
//  ExchangeRightViewController.m
//  MagookReader
//
//  Created by zhoubin on 15/10/24.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "ExchangeRightViewController.h"
#import "RightViewCell.h"
#import "CategoryModel.h"
@interface ExchangeRightViewController ()
//{
//    NSInteger _selectedIndex;
//}

@end

@implementation ExchangeRightViewController

- (void)viewDidLoad {
    [super viewDidLoad];

//    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    
    self.selectedIndex=0;

//    self.dataArray=[NSMutableArray new];
//    
//    self.tableView.tableFooterView=[[UIView alloc]init];
    
    
}
//-(void)setDataArray:(NSMutableArray *)dataArray{
//    _dataArray=dataArray;
//
//    [self.tableView reloadData];
//}
//- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
//    return 1;
//}
//
//- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
//    
//    return self.dataArray.count;
//}
//-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    if (iPad) {
//        return MINSCREEN/11;
//    }else{
//        return 44;
//    }
//}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *ID=@"RightViewCell";
    RightViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell= LOADNIBNAME(@"RightViewCell");
    }

    cell.lab.textColor=[UIColor grayColor];
    if (indexPath.row==self.selectedIndex) {
        cell.lab.textColor=COLOR;
        cell.backgroundColor=[UIColor whiteColor];
    }
    if (self.dataArray.count) {
        CategoryModel *model=self.dataArray[indexPath.row];
        cell.lab.text=model.name;
    }

    
    
    return cell;
}



@end
