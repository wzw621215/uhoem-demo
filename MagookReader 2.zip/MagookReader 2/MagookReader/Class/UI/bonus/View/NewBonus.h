//
//  NewBonus.h
//  hongbao
//
//  Created by zhoubin on 15/10/27.
//  Copyright © 2015年 zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewBonus : UIView

@property (nonatomic ,weak) UILabel *topLab;
@property (nonatomic ,weak) UILabel *bottomLab1;
@property (nonatomic ,weak) UILabel *bottomLab2;
-(void)remove;
+(void)showWithNumber:(NSNumber *)bonusNumber;
@end
