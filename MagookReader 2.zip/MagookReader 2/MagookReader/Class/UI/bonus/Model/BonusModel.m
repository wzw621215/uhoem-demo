//
//  BonusModel.m
//  MagookReader
//
//  Created by tailhuang on 15/9/30.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "BonusModel.h"

@implementation BonusModel

@end
