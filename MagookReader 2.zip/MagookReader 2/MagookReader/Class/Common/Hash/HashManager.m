//
//  HashManager.m
//  MagookReader
//
//  Created by tailhuang on 15/9/7.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "HashManager.h"

@implementation HashManager
+ (NSString *)hashWithName:(NSString *)name hashKey:(NSString *)hashKey{

    char buf[128];

    memset(buf, 0, 128);

    int ret = hash_user((unsigned char *)[name UTF8String], (unsigned char *)[hashKey UTF8String],
                        (unsigned char *)buf);
    NSString *hash;

    if (ret==0) {
        hash = [NSString stringWithUTF8String:buf];
    }
    return hash;
}
+ (NSString *)hashNameMagazineId:(NSNumber *)mid
                         issueId:(NSNumber *)iid
                       pageIndex:(NSString *)pid
                         {
    if (!(pid > 0 && [pid integerValue] <= 2000)) {
        return nil;
    }
    NSString *smid = [NSString stringWithFormat:@"%@",mid];
    NSString *siid = [NSString stringWithFormat:@"%@",iid];
     char buf[128];
     memset(buf, 0, 128);
     int ret = hash_resfile((unsigned char *)[siid UTF8String], (unsigned char *)[smid UTF8String], [pid intValue], (unsigned char *)[ORGID UTF8String], (unsigned char *)buf);
     NSString *hash;
     if (ret==0) {
         hash=[NSString stringWithUTF8String:buf];
     }
     return hash;

}

@end
