#ifndef _ResHash_h
#define _ResHash_h

static const int HASHOK  = 0;

int hash_resfile(unsigned char *issueid, unsigned char *maginfoid, int page, unsigned char *challengcode, unsigned char *hashstr);

int hash_user(unsigned char *userid, unsigned char *challengcode, unsigned char *hashstr);

#endif
