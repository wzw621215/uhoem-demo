//
//  HashManager.h
//  MagookReader
//
//  Created by tailhuang on 15/9/7.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ResHash.h"
@interface HashManager : NSObject
+ (NSString *)hashWithName:(NSString *)name hashKey:(NSString *)hashKey;
+ (NSString *)hashNameMagazineId:(NSNumber *)mid
                         issueId:(NSNumber *)iid
                       pageIndex:(NSString *)pid
                        ;
@end
