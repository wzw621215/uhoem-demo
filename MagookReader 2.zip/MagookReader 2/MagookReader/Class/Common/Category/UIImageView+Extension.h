//
//  UIImageView+Extension.h
//  MagookReader
//
//  Created by tailhuang on 15/9/20.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIImageView+WebCache.h"

@interface UIImageView (Extension)
-(void)loadImageWithSmallImage:(NSString *)smallImageUrl
                      bigImage:(NSString *)bigImageUrl
                      progress:(SDWebImageDownloaderProgressBlock)progressBlock
                     completed:(SDWebImageCompletionBlock)completedBlock;
@end
