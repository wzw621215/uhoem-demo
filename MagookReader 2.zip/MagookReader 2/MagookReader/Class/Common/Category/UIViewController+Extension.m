//
//  UIViewController+Orientation.m
//  MagookReader
//
//  Created by zhoubin on 15/11/4.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "UIViewController+Extension.h"

@implementation UIViewController (Extension)
@dynamic viewID;
-(void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{

    POSTER(OrientationWillChangeNotification, nil);
}


-(NSNumber *)viewID{

    NSString *path=[[NSBundle mainBundle]pathForResource:@"viewID" ofType:@"plist"];
    NSDictionary *viewID=[NSDictionary dictionaryWithContentsOfFile:path];

    return [viewID objectForKey:NSStringFromClass([self class])];
}
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wobjc-protocol-method-implementation"
- (void)viewWillAppear:(BOOL)animated{

    [LogManager logWithViewID:self.viewID action:@"in"];
}
-(void)viewWillDisappear:(BOOL)animated{
    [LogManager logWithViewID:self.viewID action:@"out"];
}
-(void)viewDidLoad{

}

#pragma clang diagnostic pop


@end
