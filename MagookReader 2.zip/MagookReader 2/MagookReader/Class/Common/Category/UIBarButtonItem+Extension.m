//
//  UIBarButtonItem+Extension.m
//  黑马微博2期
//
//  Created by apple on 14-10-7.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "UIBarButtonItem+Extension.h"
#import "MGButton.h"
#import "MGProgressButton.h"
@implementation UIBarButtonItem (Extension)

+ (UIBarButtonItem *)itemWithTarget:(id)target action:(SEL)action image:(NSString *)image highImage:(NSString *)highImage
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];

    [btn setBackgroundImage:[UIImage imageNamed:image] forState:UIControlStateNormal];

    [btn setBackgroundImage:[UIImage imageNamed:highImage] forState:UIControlStateHighlighted];
    btn.size=CGSizeMake(30, 30);

    return [[UIBarButtonItem alloc] initWithCustomView:btn];
}

+ (UIBarButtonItem *)itemWithTitle:(NSString *)title selectedTitle:(NSString *)selectedTitle target:(id)target action:(SEL)action image:(NSString *)image selectedImage:(NSString *)selectedImage
{

    MGButton *btn =[MGButton buttonWithType:UIButtonTypeCustom];
    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
        // 设置图片
    [btn setImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    if (selectedImage){
    [btn setImage:[UIImage imageNamed:selectedImage] forState:UIControlStateSelected];
    }

    // 设置尺寸
    btn.size = CGSizeMake(60,40);
    [btn setTitleColor:COLOR forState:UIControlStateNormal];
    if (selectedImage) {

        [btn setTitle:selectedTitle?selectedTitle:title forState:UIControlStateSelected];
    }
    [btn setTitle:title forState:UIControlStateNormal];


    btn.titleLabel.font=[UIFont systemFontOfSize:12.0f];

    btn.titleLabel.textAlignment=NSTextAlignmentCenter;

    return [[UIBarButtonItem alloc] initWithCustomView:btn];
}

+ (UIBarButtonItem *)rightItemWithTarget:(id)target action:(SEL)action image:(NSString *)image highImage:(NSString *)highImage
{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    // 设置图片
    [btn setBackgroundImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:highImage] forState:UIControlStateHighlighted];
    // 设置尺寸
    btn.size = CGSizeMake(35, 35);

    return [[UIBarButtonItem alloc] initWithCustomView:btn];
}
+(UIBarButtonItem *)downloadItemWithTarget:(id)target action:(SEL)action{

    MGProgressButton *btn =[MGProgressButton buttonWithType:UIButtonTypeCustom];
    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    // 设置图片
    [btn setImage:[UIImage imageNamed:@"下载"] forState:UIControlStateNormal];

    // 设置尺寸
    btn.size = CGSizeMake(60,40);

    [btn setTitleColor:COLOR forState:UIControlStateNormal];

    [btn setTitle:@"下载" forState:UIControlStateNormal];


    btn.titleLabel.font=[UIFont systemFontOfSize:12.0f];

    btn.titleLabel.textAlignment=NSTextAlignmentCenter;

    return [[UIBarButtonItem alloc] initWithCustomView:btn];


}
@end
