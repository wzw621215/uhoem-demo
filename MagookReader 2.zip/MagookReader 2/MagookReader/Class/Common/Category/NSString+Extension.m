//
//  NSString+Extension.m
//  MagookReader
//
//  Created by tailhuang on 15/9/7.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "NSString+Extension.h"
#import <CommonCrypto/CommonDigest.h>
#import "HashManager.h"
@implementation NSString (Extension)
-(BOOL)isAllNumber{

    for (int i=0; i<self.length; i++) {

        char c =[self characterAtIndex:i];


        if (c<'0'||c>'9') {

            return NO;
        }
    }

    return YES;
}
-(NSString *)hashString{

    return [HashManager hashWithName:self hashKey:ORGID];
}
-(NSString *)pageHashWithMagazineID:(NSNumber *)mgzId issueID:(NSNumber *)issueID {

    return [HashManager hashNameMagazineId:mgzId issueId:issueID pageIndex:self];
}
-(NSString *) md5String

{

    const char *original_str = [self UTF8String];

    unsigned char result[CC_MD5_DIGEST_LENGTH];

    CC_MD5(original_str, (CC_LONG)strlen(original_str), result);

    NSMutableString *hash = [NSMutableString string];

    for (int i = 0; i < 16; i++)

        [hash appendFormat:@"%02X", result[i]];

    return [hash lowercaseString];
    
}
+(NSString*)sizeFromByte:(NSInteger)cacheSize{
    
    NSString *str;
    
    if (cacheSize==0) {
        str=@"0";
    }else if (cacheSize<1024) {
        str=[NSString stringWithFormat:@"%d B",(int)cacheSize];
    }else if(cacheSize >=1024&&cacheSize<1024*1024){
        str=[NSString stringWithFormat:@"%.2fKB",cacheSize/1024.0];
    }else if(cacheSize >=1024*1024&&cacheSize<1024*1024*1024){
        str=[NSString stringWithFormat:@"%.2fM",cacheSize/(1024.0*1024.0)];
    }else{
        str=[NSString stringWithFormat:@"%.2fG",cacheSize/(1024.0*1024.0*1024.0)];
    }


    return str;
}
+(BOOL)isValidateEmail:(NSString *)email {
    
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    
    return [emailTest evaluateWithObject:email];
    
}
@end