//
//  MGNavigationConroller.h
//  MagookReader
//
//  Created by tailhuang on 15/9/9.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, MGRightItemType)  {
    MGRightItemTypeSearch,
    MGRightItemTypeScan,
    MGRightItemTypeVIP
};

@interface MGNavigationConroller : UINavigationController

-(void) addItemWithType:(MGRightItemType)type inVc:(UIViewController *)vc;
-(void) clearItems;
@end
