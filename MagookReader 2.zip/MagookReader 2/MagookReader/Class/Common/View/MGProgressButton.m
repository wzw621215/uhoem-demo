//
//  MGButton.m
//  MagookReader
//
//  Created by tailhuang on 15/9/17.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "MGProgressButton.h"
@interface MGProgressButton()
@property (nonatomic, strong) UAProgressView *progressView;

@end
@implementation MGProgressButton
-(instancetype)initWithFrame:(CGRect)frame{
    if(self                       = [super initWithFrame:frame]){
    self.progressView             = [[UAProgressView alloc]init];
    self.progressView.backgroundColor=[UIColor clearColor];
    self.progressView.tintColor   = COLOR;
    self.progressView.progress    = 0.0;
    self.progressView.fillOnTouch = NO;
    [self.imageView addSubview:self.progressView];
    }
    return self;
}
-(void)drawRect:(CGRect)rect{
    self.progressView.frame       = self.imageView.bounds;

}
-(void)setProgress:(CGFloat )progress{
    _progress                     = progress;

    [self.progressView setProgress:progress animated:YES];
    if (progress==0) {
        //未开始下载
        [self setImage:[UIImage imageNamed:@"下载"]forState:UIControlStateNormal];
        [self setTitle:@"下载" forState:UIControlStateNormal];

    }else if(progress>=1){
        //已下载完成
        [self setImage:[UIImage imageNamed:@"已下载"]forState:UIControlStateNormal];
        [self setTitle:@"已下载" forState:UIControlStateNormal];
        [self.progressView removeFromSuperview];
    self.progressView             = nil;
    self.enabled                  = NO;

    }else{
        //下载到一半
        if (self.isDownloading) {
            //正在下载
            [self setImage:[UIImage imageNamed:@"暂停下载"]forState:UIControlStateNormal];
            [self setTitle:@"正在下载" forState:UIControlStateNormal];
        }else{
            //暂停下载
            [self setImage:[UIImage imageNamed:@"继续下载"]forState:UIControlStateNormal];
            [self setTitle:@"继续下载" forState:UIControlStateNormal];
        }
    }
}
-(instancetype)initWithCoder:(NSCoder *)aDecoder{
    if (self=[super initWithCoder:aDecoder]) {
    self.progressView             = [[UAProgressView alloc]init];
    self.progressView.backgroundColor=[UIColor clearColor];
    self.progressView.tintColor=[UIColor redColor];
    self.progressView.frame       = self.imageView.bounds;
    self.progressView.progress    = 0.0;

    self.progressView.fillOnTouch = NO;
        [self.imageView addSubview:self.progressView];
    }
    return self;
}



@end
