//
//  MGButton.h
//  MagookReader
//
//  Created by tailhuang on 15/9/17.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MGButton : UIButton

@end
