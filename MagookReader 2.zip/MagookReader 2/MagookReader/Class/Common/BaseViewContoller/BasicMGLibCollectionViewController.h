//
//  BasicCollectionViewController.h
//  MagookReader
//
//  Created by tailhuang on 15/9/22.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import "BasicCollectionViewController.h"
@class LibDataModel,MGIssueModel;
@interface BasicMGLibCollectionViewController : BasicCollectionViewController
@property (nonatomic, strong) LibDataModel *model;
@property (nonatomic ,assign) NSInteger bonusNumber;
@property (nonatomic ,assign) BOOL isLimited;
@property (nonatomic, copy) void(^block)(MGIssueModel *);
@end
