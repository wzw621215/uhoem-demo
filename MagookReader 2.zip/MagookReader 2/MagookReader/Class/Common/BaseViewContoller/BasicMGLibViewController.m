//
//  BasicMGLibViewController.m
//  MagookReader
//
//  Created by zhoubin on 15/12/3.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "BasicMGLibViewController.h"
#import "MGLibHandle.h"
#import "MGIssueModel.h"
#import "CategoryModel.h"
#import "LibDataModel.h"
#import "MJExtension.h"
#import "MGLibCollectionViewController.h"
#import "BasicMGLibRightViewController.h"
#define ARCHIVERPATH [CACHEPATH stringByAppendingPathComponent:MGLIBARCHIVER]
@interface BasicMGLibViewController ()

@end

@implementation BasicMGLibViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=BKCOLOR;
    [self addObserver];
}
-(void)getOringinData{
    NSArray *dataArray=[NSKeyedUnarchiver unarchiveObjectWithFile:ARCHIVERPATH];
    if (dataArray&&dataArray.count) {
        NSLog(@"从缓存读取今日新刊");
        LibDataModel *model=[LibDataModel new];
        model.category=@0;
        if ([dataArray isKindOfClass:[NSArray class]]) {
            model.dataArray=[NSMutableArray arrayWithArray:dataArray];
            
            [self.mainDataDic setObject:model forKey:@"0"];
            self.collectionVC.model=model;
        }
        
    }else{
        NSLog(@"从网络加载今日新刊");
        [self loadDataWithCategory:@0 Page:@1 finish:^(LibDataModel *libModel) {
            
        }];
    }
    
}
#pragma mark -添加观察者
-(void)addObserver{
    
    OBSERVER(PullRfreshNotification, @selector(pullRefresh:));
    OBSERVER(PushLoadNotification, @selector(pushLoad:));

}

-(void)dealloc{
    REMOVEOBSERVER;
}
#pragma mark - 观察者方法
-(void)pullRefresh:(NSNotification *)notice{
    LibDataModel *model = notice.object;
    
    model.page=@1;
    [model.dataArray removeAllObjects];
    
    [self loadDataWithCategory:model.category Page:model.page finish:^(LibDataModel *libModel) {
        
    }];
    
}
-(void)pushLoad:(NSNotification *)notice{
    NSLog(@"上拉加载");
    LibDataModel *model = notice.object;
    NSInteger page = [model.page integerValue];
    page++;
    model.page=[NSNumber numberWithInteger:page];
    [self loadDataWithCategory:model.category Page:model.page finish:^(LibDataModel *libModel) {
        
    }];
}

#pragma mark -封装加载数据方法
-(void)loadDataWithCategory:(NSNumber *)category Page:(NSNumber *)page finish :(void (^)(LibDataModel *model))finish{
    
    NSString *categoryString =[NSString stringWithFormat:@"%@",category];
    if ([category isEqualToNumber:@0]) {
        page=@1;
    }
    [MGLibHandle getMGListDataWithCategory:category page:page completionHandler:^(id obj) {
        if (obj==nil) {
            //没有更多
            POSTER(NoMoreNotification, nil);
        }
        KEEP(obj!=nil);
        
        NSMutableArray *dataArray =[NSMutableArray arrayWithArray:[MGIssueModel objectArrayWithKeyValuesArray:[obj objectForKey:@"data"]]];
        
        LibDataModel *libModel;
        //如果存在KEY则取出
        if ([[self.mainDataDic allKeys] containsObject:categoryString]) {
            libModel=[self.mainDataDic objectForKey:categoryString];
        }else{
            //不存在就创建
            libModel=[LibDataModel new];
            libModel.category =category;
        }
        if (dataArray.count&&libModel.dataArray.count) {
            if ([[dataArray[0] magazineid] isEqualToNumber:[libModel.dataArray[0] magazineid]]) {
                NSLog(@"内容重复");
                POSTER(NoMoreNotification, nil);
                return;
            }
            KEEP(![[dataArray[0] magazineid] isEqualToNumber:[libModel.dataArray[0] magazineid]]);
        }
        NSMutableArray *temp =[NSMutableArray arrayWithArray:libModel.dataArray];
        
        [temp addObjectsFromArray:dataArray];
        
        libModel.dataArray=temp;
        
        [self.mainDataDic setObject:libModel forKey:categoryString];
        
        //归档
        //
        if ([category isEqualToNumber:@0]&&[page isEqualToNumber:@1]) {
            NSLog(@"缓存今日新刊第一页");
            //            NSLog(@"dataArray===%@---%ld",dataArray,dataArray.count);
            [NSKeyedArchiver archiveRootObject:dataArray toFile:ARCHIVERPATH];
            
        }
        
        LibDataModel *model=[self.mainDataDic objectForKey:categoryString];
        
        self.collectionVC.model=model;
        finish(model);
        
    }];
    
}
#pragma mark -右侧按钮
-(void)createRightViewWithVCClass:(Class)className{
    
    self.rightVC=[[className alloc]init];
    
    self.rightVC.view.autoresizingMask=UIViewAutoresizingNone;
    
    //传递数据
    [MGLibHandle getRightButtonTitlesCompletionHandler:^(id obj) {
        //用来存右侧标题模型的数组
        NSMutableArray *titleArray=[NSMutableArray new];
        
        for (NSDictionary *d in [obj objectForKey:@"data"]) {
            CategoryModel *model = [CategoryModel modelWithDic:d];
            [titleArray addObject:model];
        }
        
        self.rightVC.dataArray=titleArray;
    }];
    
    __weak typeof(self) weakSelf=self;
    self.rightVC.block=^(NSInteger index){
        if ([AppController sharedController].netWorkStatus==NetWorkStatusNotReachable) {
            [ZBHud showErrorWithMessage:@"网络连接失败！"];
            return ;
        }
        //如果存在KEY则直接切换数据源
        if ([[weakSelf.mainDataDic allKeys] containsObject:[NSString stringWithFormat:@"%ld",index]]) {
            
            weakSelf.collectionVC.model=[weakSelf.mainDataDic objectForKey:[NSString stringWithFormat:@"%ld",index]];
            
        }else{
            //不存在则重新请求（请求完毕更新数据源）
            [weakSelf loadDataWithCategory:[NSNumber numberWithInteger:index] Page:@1 finish:^(LibDataModel *libModel) {
                
            }];
        }
        //滚动到起始位置
        if (weakSelf.collectionVC.collectionView) {
            weakSelf.collectionVC.collectionView.contentOffset=CGPointZero;
        }
    };
    [self.view addSubview:self.rightVC.view];
    
    [self.rightVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(NAV_HEIGHT);
        make.right.equalTo(self.view);
        make.bottom.mas_equalTo(-TAB_HEIGHT);
        make.width.mas_equalTo(RightTableW);
        
    }];
    
    
}

-(NSMutableDictionary *)mainDataDic{
    if (_mainDataDic==nil) {
        _mainDataDic=[NSMutableDictionary new];
    }
    return _mainDataDic;
}

@end
