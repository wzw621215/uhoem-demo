//
//  BasicViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/10.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicViewController.h"

@interface BasicViewController ()

@end

@implementation BasicViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = BKCOLOR;
}


@end
