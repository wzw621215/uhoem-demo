//
//  BasicMGLibRightViewController.h
//  MagookReader
//
//  Created by zhoubin on 15/12/4.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BasicMGLibRightViewController : UITableViewController
@property (nonatomic ,assign) NSInteger selectedIndex;
@property (nonatomic, strong) NSArray *dataArray;
@property (nonatomic, copy) void (^block)(NSInteger selectedIndex);
@end
