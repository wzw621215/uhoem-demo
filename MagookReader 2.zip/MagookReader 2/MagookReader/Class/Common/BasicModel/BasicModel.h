//
//  BasicModel.h
//  MagookReader
//
//  Created by tailhuang on 15/9/8.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BasicModel : NSObject

@end
