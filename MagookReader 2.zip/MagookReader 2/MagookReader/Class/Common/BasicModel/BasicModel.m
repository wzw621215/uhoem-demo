//
//  BasicModel.m
//  MagookReader
//
//  Created by tailhuang on 15/9/8.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicModel.h"

@implementation BasicModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{

}


@end
