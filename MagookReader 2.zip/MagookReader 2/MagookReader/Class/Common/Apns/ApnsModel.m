//
//  ApnsModel.m
//  MagookReader
//
//  Created by zhoubin on 15/10/29.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "ApnsModel.h"
#import "MJExtension.h"
@implementation ApnsModel
MJExtensionCodingImplementation
-(instancetype)initWithDic:(NSDictionary *)dic{
    if(self=[super init]){
        [self setValuesForKeysWithDictionary:dic];
        if (self.text) {
            self.type = ApnsTypeText;
        }else if (self.newmagazine) {
            self.type = ApnsTypeNewmagazine;
        }else if(self.openurl){
            self.type = ApnsTypeOpenurl;
        }else if(self.openissue){
            self.type = ApnsTypeOpenissue;
        }else if(self.racknewissue){
            self.type = ApnsTypeRacknewissue;
        }else if(self.newbonus){
            self.type = ApnsTypeNewbonus;
        }

    }
    return self;
}
+(instancetype)modelWithDic:(NSDictionary *)dic{
    return [[self alloc]initWithDic:dic];
}
/**
 ApnsTypeText,
 ApnsTypeUpdate,
 ApnsTypeNewmagazine,
 ApnsTypeOpenurl,
 ApnsTypeOpenissue,
 ApnsTypeRacknewissue,
 ApnsTypeNewbonus
 */
+(NSDictionary *)dicWithModel:(ApnsModel *)model{
    NSMutableDictionary *dic=[NSMutableDictionary new];
    [dic setObject:model.title forKey:@"title"];
    [dic setObject:model.desc forKey:@"desc"];
    [dic setObject:[NSNumber numberWithInteger:model.type] forKey:@"type"];
    [dic setObject:[NSNumber numberWithBool:model.isRead] forKey:@"isRead"];
    switch (model.type) {

        case ApnsTypeText:
            [dic setObject:model.text forKey:@"text"];
            break;
        case ApnsTypeUpdate:
            [dic setObject:model.update forKey:@"update"];
            break;
        case ApnsTypeNewmagazine:
            [dic setObject:model.newmagazine forKey:@"newmagazine"];
            break;
        case ApnsTypeOpenurl:
            [dic setObject:model.openurl forKey:@"openurl"];
            break;
        case ApnsTypeOpenissue:
            [dic setObject:model.openissue forKey:@"openissue"];
            break;
        case ApnsTypeRacknewissue:
            [dic setObject:model.racknewissue forKey:@"racknewissue"];
            break;
        case ApnsTypeNewbonus:
            [dic setObject:model.newbonus forKey:@"newbonus"];
            break;


        default:
            break;
    }
    return dic;
}


@end
