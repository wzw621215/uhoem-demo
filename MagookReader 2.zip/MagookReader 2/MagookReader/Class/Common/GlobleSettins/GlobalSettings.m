//
//  GlobleSettings.m
//  MagookReader
//
//  Created by user on 15/9/5.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "GlobalSettings.h"
#import "PayHandle.h"

#define SERVERCACHEPATH [DOCUMENTSPATH stringByAppendingPathComponent:@"serverData.plist"]
@implementation GlobalSettings
static id settins = nil;
-(BOOL)doublePage{
    id obj=[[NSUserDefaults standardUserDefaults]objectForKey:DoublePageStatus];
    
    BOOL isOn;
    if (obj==nil||[obj boolValue]==NO) {
        isOn=NO;
    }else{
        isOn=YES;
    }
    return isOn;
}
+(instancetype)sharedSettings{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        settins = [[self alloc]init];
    });
    return settins;
}
+ (id)allocWithZone:(struct _NSZone *)zone
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        settins = [super allocWithZone:zone];
    });
    return settins;
}

-(instancetype)init{

    if (self = [super init]) {

        [self configDevice];
    
    }
    return self;
}
-(void)configDevice{
    NSLog(@"配置device");
    NSDictionary *dic = [[NSBundle mainBundle]infoDictionary];
    
    _bundleID = dic[@"CFBundleIdentifier"];
    
    NSString *projectname = dic[@"CFBundleExecutable"];

    NSNumber *version = @(APPVersion);
    NSString *platformType = [UIDevice currentDevice].model;
    
    NSString *system =SYSTEM;
    
    NSString *systemVersion = [UIDevice currentDevice].systemVersion;
    
    NSString *screen = [NSString stringWithFormat:@"%dX%d",(int)SCREEN_WIDTH*(int)SCALE,(int)SCREEN_HEIGHT*(int)SCALE];
    
    _userAgent = [NSString stringWithFormat:@"%@/%@ (%@; %@ %@); %@",projectname,version,platformType,systemVersion,system,screen];
    
    NSString *machinecode = [UIDevice currentDevice].identifierForVendor.UUIDString;
    
    NSNumber *clientplatform =@(PlatformType);
    //        [platformType hasPrefix:@"iPhone"]?@(PlatformTypeIPhone):@(PlatformTypeIPad);
    NSNumber *apptypeid = @(APPTypeID);
    
    NSNumber *appversion = version;
    
    NSString *devicemodel = platformType;
    
    NSString *resolution = screen;
    
    NSString *devicetoken_umeng;
    
    NSString *devicetoken=[[NSUserDefaults standardUserDefaults]objectForKey:@"devicetoken"];
    
    if (devicetoken) {
        devicetoken_umeng=devicetoken;
    }else{
        devicetoken_umeng= @"unknown";
    }
    NSLog(@"devicetoken_umeng====%@",devicetoken_umeng);
    
    NSNumber *apiversion = @(APIVersion);
    
    _device = @{
                @"machinecode"      :machinecode,
                @"clientplatform"   :clientplatform,
                @"apptypeid"        :apptypeid,
                @"appversion"       :appversion,
                @"bundleid"         :_bundleID,
                @"devicemodel"      :devicemodel,
                @"resolution"       :resolution,
                @"systemversion"     :systemVersion,
                @"system"           :system,
                @"devicetoken_umeng":devicetoken_umeng,
                @"apiversion"       :apiversion
                };
    NSLog(@"DEVICE========>%@",[_device JSONString]);
}
-(void)rootServerInitSuccess:(void (^)(BOOL))successBlock{

    //此处改成同步请求，在初始化未完成前卡住主线程
    NSData*rootData=[NSURLConnection sendSynchronousRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:ORIGINSERVERURL]] returningResponse:nil error:nil];
    id responseObject;
    if (rootData) {
    responseObject =[NSJSONSerialization JSONObjectWithData:rootData options:NSJSONReadingAllowFragments error:nil];
//        NSLog(@"ORIGIN===%@",responseObject);
    }
    if (responseObject==nil) {
        [ZBHud showErrorWithMessage:@"服务器初始化失败"];
        NSLog(@"根服务器初始化失败,使用缓存数据");
        NSArray *serverData = [NSArray arrayWithContentsOfFile:SERVERCACHEPATH];
        [self confirmServerWithData:serverData];
        successBlock(NO);
        return;
    }
    NSDictionary *server = responseObject[@"server"];
    NSArray *dataArray = server[@"data"];
    [self confirmServerWithData:dataArray];

    NSLog(@"根服务器初始化完毕");
    //初始化购买服务器
    [self purchaseInit];
    
    //INIT/INIT
    [self bussinisInitFinish:^(BOOL isFinish) {
        successBlock(isFinish);
    }];
    
}
-(void)purchaseInit{
    [PayHandle purchaseInitFinish:^(id object) {
        
//        NSLog(@"%@",object);
        if (object==nil) {
            NSLog(@"购买服务器初始化失败");
            
            return ;
        }
        //一种套餐
        NSArray *rootArray=[object valueForKeyPath:@"buypackage.data"];
        NSPredicate *pre30 = [NSPredicate predicateWithFormat:@"name == '1种套餐'"];
        NSArray *arrayPre30=[rootArray filteredArrayUsingPredicate: pre30];
        _buyPackage30=arrayPre30[0][@"packageid"];
        //VIP
        NSPredicate *preVIP = [NSPredicate predicateWithFormat:@"name == '终身VIP套餐'"];
        NSArray *arrPre4998=[rootArray filteredArrayUsingPredicate:preVIP];
        _buyPackage4998=arrPre4998[0][@"packageid"];
        //红包
        NSPredicate *preBonus = [NSPredicate predicateWithFormat:@"name == '杂志通用红包'"];
        NSArray *arrBonus=[rootArray filteredArrayUsingPredicate:preBonus];
        _buyPackageBonus=arrBonus[0][@"packageid"];
    }];
}
-(void)bussinisInitFinish:(void (^)(BOOL isFinish))finish{
    NSString *businessUrl = [NSString stringWithFormat:@"%@init/init",_businessServer];
    NSLog(@"%@",businessUrl);
    if (_businessServer==nil) {
        NSLog(@"businessServer为空");
        finish(NO);
        return;
    }
    NSDictionary *mapdate = @{ //各映射表更新时间yyyyMMddHH
                              @"date":@"0",
                              @"doings":@"0",
                              @"level":@"0",
                              @"buypackage":@"0",
                              @"pay":@"0",
                              @"server":@"0"
                              } ;
    NSDictionary *param = @{
                            @"device":DEVICE,
                            @"mapdate":mapdate
                            };
    NSData *postData=[param JSONData];
    NSMutableURLRequest *request =[NSMutableURLRequest requestWithURL:[NSURL URLWithString:businessUrl]];
    request.timeoutInterval=TimeOutInterval;
    [request setValue:@"POST" forKey:@"HTTPMethod"];
    [request setHTTPBody: postData];
    NSData *bussinessData=[NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    if (bussinessData&&bussinessData.length) {
        NSDictionary *responseObject=[bussinessData objectFromJSONData];
        if (responseObject==nil) {
            [ZBHud showErrorWithMessage:@"服务器初始化失败"];
            NSLog(@"init/init失败");
            finish(NO);
            return ;
        }
        self.deviceid=responseObject[@"deviceid"];
        self.sessionID=responseObject[@"sessionid"];

        NSLog(@"reviewstatus========%@",[responseObject valueForKeyPath:@"appreview"]);
        INREVIEW=[[responseObject valueForKeyPath:@"appreview.reviewstatus"] boolValue];
        [AppController sharedController].useridInReview=[responseObject valueForKeyPath:@"appreview.user.userid"];
        [AppController sharedController].userHashInReview=[NSString stringWithFormat:@"%@",[responseObject valueForKeyPath:@"appreview.user.userhash"]];
        
        NSArray *dataArray=[responseObject valueForKeyPath:@"server.data"];
        NSPredicate *pre = [NSPredicate predicateWithFormat:@"name == 'share'"];
        self.shareServer=[[dataArray filteredArrayUsingPredicate:pre][0] objectForKey:@"url"];
        //是否开启红包
        NSArray *funcswitch=[responseObject objectForKey:@"funcswitch"];
        NSPredicate *funpre = [NSPredicate predicateWithFormat:@"name == 'enablebonus'"];
        NSArray *enablebonus=[funcswitch filteredArrayUsingPredicate:funpre];
        [AppController sharedController].enablebonus=[[enablebonus[0] objectForKey:@"value"] boolValue];

//        INREVIEW=NO;
//        ENABLEBONUS=YES;
        NSArray *serverData =responseObject[@"server"][@"data"];
        //将服务器写入文件
        
        [serverData writeToFile:SERVERCACHEPATH atomically:YES];
        [self confirmServerWithData:serverData];
        NSLog(@"全部初始化完毕");
        finish(YES);
    }else{
        finish(NO);
    }

}
-(void)confirmServerWithData:(NSArray *)serverData{
    KEEP(serverData!=nil);
    for (NSDictionary *d in serverData) {
        NSString *name = d[@"name"];
        if ([name isEqualToString:@"business"]) {
            _businessServer = d[@"url"];
            
        }else if([name isEqualToString:@"ids"]){
            _idsServer=d[@"url"];
        }
        else if([name isEqualToString:@"log"]){
            _logServer=d[@"url"];
        }
        else if([name isEqualToString:@"businesscache"]){
            _businesscacheServer=d[@"url"];
        }
        else if([name isEqualToString:@"page"]){
            _pageServer=d[@"url"];
        }
        else if([name isEqualToString:@"download"]){
            _downloadServer=d[@"url"];
        }
        else if([name isEqualToString:@"logoimg"]){
            _logoimgServer=d[@"url"];
        }
        else if([name isEqualToString:@"urlbase"]){
            _urlbaseServer=d[@"url"];
        }
        else if([name isEqualToString:@"share"]){
            _shareServer=d[@"url"];
        }
        else if([name isEqualToString:@"purchase"]){
            _purchaseServer=d[@"url"];
        }
    }
}
@end

