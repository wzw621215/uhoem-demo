//
//  GlobleSettings.h
//  MagookReader
//
//  Created by user on 15/9/5.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>

#define BUNDLEID  [GlobalSettings sharedSettings].bundleID
#define USERTOKEN [GlobalSettings sharedSettings].userToken
#define USERAGENT [GlobalSettings sharedSettings].userAgent
#define DEVICE    [GlobalSettings sharedSettings].device
#define DEVICEID    [GlobalSettings sharedSettings].deviceid
#define SESSIONID [GlobalSettings sharedSettings].sessionID

#define BUSSINESSSERVER       [GlobalSettings sharedSettings].businessServer
#define IDSSERVER             [GlobalSettings sharedSettings].idsServer
#define LOGSERVER             [GlobalSettings sharedSettings].logServer
#define URLSERVER             [GlobalSettings sharedSettings].urlbaseServer
#define BUSSINESCACHESSERVER  [GlobalSettings sharedSettings].businesscacheServer
#define PAGESERVER            [GlobalSettings sharedSettings].pageServer
#define SHARESERVER           [GlobalSettings sharedSettings].shareServer
#define PURCHASSERVER         [GlobalSettings sharedSettings].purchaseServer
#define FUNCSWITCH            [GlobalSettings sharedSettings].funcswitch

#define BUYPACKAGE30          [GlobalSettings sharedSettings].buyPackage30
#define BUYPACKAGEVIP         [GlobalSettings sharedSettings].buyPackage4998
#define BUYPACKAGEBONUS       [GlobalSettings sharedSettings].buyPackageBonus
#define DOUBLEPAGE            [GlobalSettings sharedSettings].doublePage

//订单类型（0,平台币充值;1,杂志购物车;2,红包兑换;3，终身VIP）

typedef NS_OPTIONS(NSUInteger, Ordertype) {
    OrdertypeMaidou,
    OrdertypeShoppingCart,
    OrdertypeBonus,
    OrdertypeVip
};

@interface GlobalSettings : NSObject

@property (nonatomic, copy) NSString     *sessionID;
@property (nonatomic, copy) NSString     *userToken;
@property (nonatomic, copy) NSString     *userAgent;
@property (nonatomic, copy) NSString     *bundleID;

@property (nonatomic, copy) NSDictionary *device;
@property (nonatomic, copy) NSString     *deviceid;
//@property (nonatomic ,copy) NSString     *devicetoken;

@property (nonatomic, copy) NSString     *businessServer;
@property (nonatomic, copy) NSString     *idsServer;
@property (nonatomic, copy) NSString     *logServer;
@property (nonatomic, copy) NSString     *businesscacheServer;
@property (nonatomic, copy) NSString     *pageServer;
@property (nonatomic, copy) NSString     *downloadServer;
@property (nonatomic, copy) NSString     *logoimgServer;
@property (nonatomic, copy) NSString     *urlbaseServer;
@property (nonatomic, copy) NSString     *shareServer;
@property (nonatomic, copy) NSString     *purchaseServer;
@property (nonatomic, strong) NSArray    *funcswitch;

@property (nonatomic, copy) NSNumber     *buyPackage30;
@property (nonatomic, copy) NSNumber     *buyPackage4998;
@property (nonatomic, copy) NSNumber     *buyPackageBonus;

@property (nonatomic ,assign) BOOL doublePage;
+(instancetype)sharedSettings;
-(void)configDevice;
-(void)rootServerInitSuccess:(void (^)(BOOL isSuccess))successBlock;
@end
