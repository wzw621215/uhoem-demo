//
//  LogManager.h
//  MagookReader
//
//  Created by zhoubin on 15/11/10.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>
#define LOGPATH [DOCUMENTSPATH stringByAppendingPathComponent:@"log.txt"]
@interface LogManager : NSObject
//+(instancetype)sharedManager;

+(void)logWithViewID:(NSNumber *)viewID action:(NSString *)action info:(NSString *)info;
+(void)logWithViewID:(NSNumber *)viewID action:(NSString *)action;
+(void)logWithViewID:(NSNumber *)viewID;
+(void)sendLogToServer;
+(void)removeLog;
@end
