//
//  DownloadManager.m
//  DownloadManagerDemo
//
//  Created by tailhuang on 15/10/10.
//  Copyright © 2015年 Leo. All rights reserved.
//

#import "DownloadManager.h"
#import "AFNetworking.h"
#import "LCDownloadManager.h"
#import "ReadingHadle.h"
#import "DownloadDataManager.h"

@implementation DownloadManager
static  DownloadManager *manager=nil;
+(instancetype)sharedManager{

    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (manager==nil) {
            manager = [[self alloc]init];
        }
    });

    return manager;

}
-(BOOL)isDownloadingWithModel:(MGIssueModel *)model{
    NSArray *array=[self.dataDic allKeys];
    return [array containsObject:[NSString stringWithFormat:@"%@",model.issueid]];
}
-(NSMutableDictionary *)dataDic{
    if (!_dataDic) {
        _dataDic=[NSMutableDictionary new];
    }
    return _dataDic;
}
-(SDWebImageCombinedOperation *)downloadWithModel:(MGIssueModel *)model progress:(progressBlock)progressBlock{

    NSString *url=[ReadingHadle getBigUrlAtPage:model.downloadedNumber+1 WithModel:model];
    NSString *directoryName = [NSString stringWithFormat:@"%@_%@",model.magazinename,model.issuename];
    NSString *fileName = [NSString stringWithFormat:@"%ld",model.downloadedNumber+1];
    
    
    model.sd_operation = [DownloadHandle downloadWithURL:url directoryName:directoryName fileName:fileName complete:^(UIImage *image, NSURL *imageUrl, long long size) {
        
        //强制暂停

        KEEP(model.sd_operation!=nil);
        if (model.downloadedNumber==0) {
            NSString *directoryPath = [NSString stringWithFormat:@"%@/%@/%@",DOCUMENTSPATH,DownloadDirectoryName,directoryName];
            [self downloadContentWithModel:model directory:directoryPath];
        }
        
        if (model.downloadedNumber<[model.count integerValue]) {
            model.downloadedNumber ++;
        }
        CGFloat progress =(float)model.downloadedNumber/[model.count integerValue];
        if (model.downloadedNumber<[model.count integerValue]) {
            model.sd_operation=[self downloadWithModel:model progress:progressBlock];
        }else{
            
            [self pauseWithModel:model];
            
            NSLog(@"任务-----%@------已完成",model.magazinename);
        }
        DownloadDataManager *manager= [DownloadDataManager sharedManager];
        
        //数据即时存入数据库
        
        if ([manager isExistsDataWithModel:model]) {
            [manager changeDataWithModel:model];
        }else{
            [manager insertDataWithModel:model];
            //发送新任务通知
            NSLog(@"新建下载任务");
            POSTER(NewDownloadMissionIsBuildNotification, model);
        }
        //发送进度改变的通知
        POSTER(UpdateDownloadProgressNotification, nil);
        progressBlock(progress,model);
        
    }];
     [self.dataDic setValue:model forKey:[NSString stringWithFormat:@"%@",model.issueid]];
    return model.sd_operation;
    
}

#pragma mark - 下载目录
-(void)downloadContentWithModel:(MGIssueModel *)model directory:(NSString *)directory{

    NSLog(@"下载目录");
    NSString *url =[NSString stringWithFormat:@"%@magazine/magazine_%@/catalog/catalog_%@.txt",BUSSINESCACHESSERVER,model.magazineid,model.issueid];
    
    [NSURLConnection sendAsynchronousRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]] queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        
        NSDictionary *root=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        [root writeToFile:[directory stringByAppendingPathComponent:@"content.plist"] atomically:YES];
        NSLog(@"目录下载成功");
    }];
}
#pragma mark - 暂停
-(void)pauseWithModel:(MGIssueModel *)model{

    NSLog(@"暂停%@,%@",model.magazinename,model.issuename);

    [DownloadHandle pauseWithOperation:model.sd_operation];
    model.sd_operation=nil;
    [self.dataDic removeObjectForKey:[NSString stringWithFormat:@"%@",model.issueid]];
    //将issid对应的model的(operation)值赋给需要暂停的model，保证可以停下来
//    if ([self.dataDic objectForKey:[NSString stringWithFormat:@"%@",model.issueid]]) {
//        MGIssueModel *tempModel=[self.dataDic objectForKey:[NSString stringWithFormat:@"%@",model.issueid]];
//        model=tempModel;
//    }
//
//    
//    [LCDownloadManager pauseWithOperation:model.operation];
//
//    [model.operation cancel];
//
//    model.operation=nil;
//
    

}
-(void)cleanDataWithModel:(MGIssueModel *)model{
    model.downloadedNumber=0;
    [self.dataDic removeObjectForKey:[NSString stringWithFormat:@"%@",model.issueid]];
}
@end
