//
//  DownloadManager.h
//  DownloadManagerDemo
//
//  Created by tailhuang on 15/10/10.
//  Copyright © 2015年 Leo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "MGIssueModel.h"
#import "DownloadHandle.h"
//typedef void(^Success)(CGFloat progress,NSString *directory);
typedef void(^progressBlock)(CGFloat progress,MGIssueModel *model);
//typedef void(^Failure)(AFHTTPRequestOperation *operation, NSError *error);
@interface DownloadManager : NSObject
//用于保存正在下载中的任务
@property (nonatomic, strong) NSMutableDictionary *dataDic;
+(instancetype)sharedManager;

//-(AFHTTPRequestOperation *)downloadFileWithModel:(MGIssueModel *)model success:(Success)success;
-(SDWebImageCombinedOperation *)downloadWithModel:(MGIssueModel *)model progress:(progressBlock)progressBlock;
-(void)pauseWithModel:(MGIssueModel *)model;
-(BOOL)isDownloadingWithModel:(MGIssueModel *)model;
-(void)cleanDataWithModel:(MGIssueModel *)model;
@end
