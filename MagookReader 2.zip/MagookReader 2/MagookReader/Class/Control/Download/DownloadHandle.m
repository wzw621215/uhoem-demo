//
//  DownloadHandle.m
//  MagookReader
//
//  Created by zhoubin on 15/11/17.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "DownloadHandle.h"
#define DIRECTORY [DOCUMENTSPATH stringByAppendingPathComponent:@"下载"]

@implementation DownloadHandle
+(SDWebImageCombinedOperation *)downloadWithURL:(NSString *)url directoryName:(NSString *)directoryName fileName:(id)name complete:(finishBlock)finish{
    //禁用压缩
    //    [[SDImageCache sharedImageCache] setShouldDecompressImages:NO];
    //    [[SDWebImageDownloader sharedDownloader] setShouldDecompressImages:NO];

    //创建文件夹
    BOOL isDirectory                   = YES;
    NSFileManager *fileManager         = [NSFileManager defaultManager];
    NSString *filePath = [DIRECTORY stringByAppendingPathComponent:directoryName];
    if (![fileManager fileExistsAtPath:filePath isDirectory:&isDirectory]) {
        [fileManager createDirectoryAtPath:filePath withIntermediateDirectories:YES attributes:nil error:nil];
    }
    SDWebImageCombinedOperation *opreation=[[SDWebImageManager sharedManager]
                                            downloadImageWithURL:[NSURL URLWithString:url]
                                            options:0
                                            progress:nil
                                            completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, BOOL finished, NSURL *imageURL) {
                                                if (image) {
                                                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                                                        
                                                        //转换格式webp->png，并存储
                                                      [UIImagePNGRepresentation(image) writeToFile: [filePath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.png",name]]   atomically:YES];
                                                        //计算文件夹大小
                                                        long long size = [self folderSizeAtPath:DIRECTORY];
                                                        dispatch_async(dispatch_get_main_queue(), ^{
                                                            finish(image, imageURL, size);
                                                        //下载完毕一个就清空内存缓存
                                                        [[SDImageCache sharedImageCache] setValue:nil forKey:@"memCache"];
                                                        });
                                                    });
                                                }
                                                
                                            }];
    
    return opreation;
}
+(void)pauseWithOperation:(SDWebImageCombinedOperation *)operation{
    [operation cancel];
}
//单个文件大小
+ (long long) fileSizeAtPath:(NSString*) filePath{
    
    NSFileManager* manager             = [NSFileManager defaultManager];
    
    if ([manager fileExistsAtPath:filePath]){
        
        return [[manager attributesOfItemAtPath:filePath error:nil] fileSize];
        
    }
    
    return 0;
    
}
//文件夹大小
+ (float ) folderSizeAtPath:(NSString*) folderPath{
    
    NSFileManager* manager             = [NSFileManager defaultManager];
    
    if (![manager fileExistsAtPath:folderPath]) return 0;
    
    NSEnumerator *childFilesEnumerator = [[manager subpathsAtPath:folderPath] objectEnumerator];
    
    NSString* fileName;
    
    long long folderSize               = 0;
    
    while ((fileName                   = [childFilesEnumerator nextObject]) != nil){
        
        NSString* fileAbsolutePath         = [folderPath stringByAppendingPathComponent:fileName];
        
        folderSize                         += [self fileSizeAtPath:fileAbsolutePath];
        
    }
    
    return folderSize;
    
}

@end
