//
//  CHKeychain.h
//  KeyChain3
//
//  Created by user on 15/9/4.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <Security/Security.h>


@interface ZBKeychain : NSObject

+ (void)save:(NSString *)service data:(id)data;
+ (id)load:(NSString *)service;
+ (void)delete:(NSString *)service;

@end
