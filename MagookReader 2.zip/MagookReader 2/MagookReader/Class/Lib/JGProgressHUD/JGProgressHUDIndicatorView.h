//
//  JGProgressHUDIndicatorView.h
//  JGProgressHUD
//
//  Created by Jonas Gessner on 20.7.14.
//  Copyright (c) 2014 Jonas Gessner. All rights reserved.
//  

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/**
 You may subclass this class to create a custom progress indicator view.
 */
@interface JGProgressHUDIndicatorView : UIView

/**
 Ranges from 0.0 to 1.0.
 */
@property (nonatomic) float progress;

/**
 Adjusts the current progress shown by the receiver, optionally animating the change.
 
 The current progress is represented by a floating-point value between 0.0 and 1.0, inclusive, where 1.0 indicates the completion of the task. The default value is 0.0. Values less than 0.0 and greater than 1.0 are pinned to those limits.
 
 @param progress The new progress value.
 @param animated YES if the change should be animated, NO if the change should happen immediately.
 */
- (void)setProgress:(float)progress animated:(BOOL)animated;

/**
 Designated initializer for this class.
 @param contentView The content view to place on the container view (the container is the JGProgressHUDIndicatorView).
 */
- (instancetype)initWithContentView:(UIView *)contentView;

/**
 The content view which displays the progress.
 */
@property (nonatomic, strong, readonly) UIView *contentView;

@end
