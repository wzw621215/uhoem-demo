//
//  FMDBManager.h
//  JiaXue++
//
//  Created by qianfeng on 15/7/29.
//  Copyright (c) 2015年 zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>
@class MGIssueModel;
@interface ShoppingCartDataManager : NSObject
+(instancetype)sharedManager;
- (BOOL)insertDataWithModel:(MGIssueModel *)model;
- (BOOL)deleteDataWithModel:(MGIssueModel *)model;
- (BOOL)isExistsDataWithModel:(MGIssueModel *)model;
- (BOOL)isExistsDataWithMagazineid:(NSString *)magazineid;
- (NSArray *)allData;
-(void)removeData;
@end
