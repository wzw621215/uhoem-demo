//
//  DownloadDataManager.m
//  MagookReader
//
//  Created by tailhuang on 15/10/11.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "DownloadDataManager.h"
#import "FMDatabase.h"
#import "MGIssueModel.h"
@implementation DownloadDataManager
{
    FMDatabase *_dataBase;
}
static DownloadDataManager *manager=nil;
+(instancetype)sharedManager{

    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (manager==nil) {
            manager = [[self alloc]init];
        }
    });

    return manager;

}
-(instancetype)init{
    if (self=[super init]) {
        NSString *documentPath = [NSHomeDirectory() stringByAppendingString:@"/Documents/Download.db"];
//                NSLog(@"%@",documentPath);
        _dataBase = [[FMDatabase alloc]initWithPath:documentPath];

        if ([_dataBase open]) {
//            NSLog(@"下载数据库打开成功");
            //自定义数据库列表

            NSString *sql = @"create table if not exists Download(magazineid,magazinename,count,guid,issueid,issuename,path,price0,price1,start,toll,downloadedNumber)";

            if ([_dataBase executeUpdate:sql]) {
//                NSLog(@"下载创建表格成功");
            }else{
                NSLog(@"下载创建表格失败");
            }


        }else{
            NSLog(@"下载数据库打开失败");
        }

    }
    return self;
}
- (BOOL)insertDataWithModel:(MGIssueModel *)model{
    NSString *sql = @"insert into Download(magazineid,magazinename,count,guid,issueid,issuename,path,price0,price1,start,toll,downloadedNumber) values (?,?,?,?,?,?,?,?,?,?,?,?)";


    BOOL isSuccess = [_dataBase executeUpdate:sql,model.magazineid,model.magazinename,model.count,model.guid,model.issueid,model.issuename,model.path,model.price0,model.price1,model.start,model.toll,[NSNumber numberWithInteger:model.downloadedNumber]];

    if (isSuccess) {
//        NSLog(@"下载插入数据成功");
    }else{
        NSLog(@"下载插入数据失败 %@",_dataBase.lastErrorMessage);
    }
    return isSuccess;
}
- (BOOL)changeDataWithModel:(MGIssueModel *)model{
    //通过issueid改downloadedNumber
    NSString *sql = @"update Download set downloadedNumber = ? where issueid = ?";

    BOOL isSuccess = [_dataBase executeUpdate:sql,[NSNumber numberWithInteger:model.downloadedNumber],model.issueid];
    //NSString *sql2 = @"update appa set iconUrl = ? where applicationId = ?";
    //...
    if (isSuccess) {
//        NSLog(@"下载修改数据成功");
    }else{
        NSLog(@"下载修改数据失败 %@",_dataBase.lastErrorMessage);
    }

    return isSuccess;
}
- (BOOL)deleteDataWithModel:(MGIssueModel *)model{
    NSString *sql = @"delete from Download where issueid = ?";
    BOOL isSuccess = [_dataBase executeUpdate:sql,model.issueid];
    if (isSuccess) {
//        NSLog(@"下载删除数据成功");
    }else{
        NSLog(@"下载删除数据失败%@",_dataBase.lastErrorMessage);
    }
    return isSuccess;
}

- (BOOL)isExistsDataWithModel:(MGIssueModel *)model{

    NSString *sql = @"select issueid from Download where issueid = ?";

    FMResultSet *set = [_dataBase executeQuery:sql,model.issueid];


    //[set next] 说明数据库有这个结果
    return [set next];
}
//根据已知的issueid把下载数据取出赋给无下载数据的模型
-(NSInteger)upDateModelWithModel:(MGIssueModel *)model{
    NSString *sql = @"select * from Download where issueid = ?";

    FMResultSet *set = [_dataBase executeQuery:sql,model.issueid];

     while ([set next]) {

//         model.directory    = [set stringForColumn:@"directory"];

         model.downloadedNumber =[[set objectForColumnName:@"downloadedNumber"] integerValue];

     }
    return model.downloadedNumber;

}
- (NSArray *)allData{

    NSMutableArray *arr = [[NSMutableArray alloc] init];

    NSString *sql = @"select * from Download";

    FMResultSet *set = [_dataBase executeQuery:sql];

    while ([set next]) {


        MGIssueModel *model = [[MGIssueModel alloc] init];

        /**
         "count": 110,
         "guid": "237481",
         "issueid": 237481,
         "issuename": "2014年1期",
         "magazineid": 6299,
         "magazinename": "建筑科学与监理",
         "path": "page1",
         "price0": 0,
         "price1": 2,
         "start": 3,
         "toll": 18
         */

        //NSString
        model.guid         = [set stringForColumn:@"guid"];
        model.issuename    = [set stringForColumn:@"issuename"];
        model.path         = [set stringForColumn:@"path"];
        model.magazinename = [set stringForColumn:@"magazinename"];
//        model.directory    = [set stringForColumn:@"directory"];
        //NSNumber
        model.count        = [set  objectForColumnName:@"count"];
        model.issueid      = [set objectForColumnName:@"issueid"];
        model.magazineid   = [set objectForColumnName:@"magazineid"];
        model.price0       = [set objectForColumnName:@"price0"];
        model.price1       = [set objectForColumnName:@"price1"];
        model.start        = [set objectForColumnName:@"start"];
        model.toll         = [set objectForColumnName:@"toll"];
        model.magazineid   = [set objectForColumnName:@"magazineid"];
        model.downloadedNumber =[[set objectForColumnName:@"downloadedNumber"] integerValue];



        [arr addObject:model];
    }
    return arr;
}
-(void)removeData{
    if (manager) {
        for (MGIssueModel *model in [manager allData]) {
            [manager deleteDataWithModel:model];
        }
    }
    
}
@end
