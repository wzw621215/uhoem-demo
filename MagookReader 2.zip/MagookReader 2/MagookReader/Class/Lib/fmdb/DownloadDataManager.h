//
//  DownloadDataManager.h
//  MagookReader
//
//  Created by tailhuang on 15/10/11.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>
@class MGIssueModel;
@interface DownloadDataManager : NSObject
+(instancetype)sharedManager;
- (BOOL)insertDataWithModel:(MGIssueModel *)model;
- (BOOL)deleteDataWithModel:(MGIssueModel *)model;
- (BOOL)isExistsDataWithModel:(MGIssueModel *)model;
- (BOOL)changeDataWithModel:(MGIssueModel *)model;
//传入无下载数据的模型，返回带下载数据的模型
-(NSInteger )upDateModelWithModel:(MGIssueModel *)model;
- (NSArray *)allData;
-(void)removeData;
@end
