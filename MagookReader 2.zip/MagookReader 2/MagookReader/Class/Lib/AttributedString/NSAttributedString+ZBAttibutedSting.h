//
//  NSAttributedString+ZBAttibutedSting.h
//  WPAttributedMarkupDemo
//
//  Created by user on 15/9/8.
//  Copyright (c) 2015年 Nigel Grange. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>
#import "NSString+WPAttributedMarkup.h"

#import "WPAttributedStyleAction.h"
#import "WPHotspotLabel.h"
@interface NSAttributedString (ZBAttibutedSting)
/**
 *  自己封装的属性字体方法，一段字体里面只能有一个属性
 *
 *  @param string           完整的字符串
 *  @param attributedString 需要添加点击事件的字符串
 *  @param fontSize         字体大小
 *  @param color            字体颜色
 *  @param action           点击方法
 *
 */
+(instancetype)stringWithText:(NSString *)string attributedString:(NSString *)attributedString fontSize:(CGFloat)fontSize color:(UIColor *)color block:(void (^)())action;
@end
