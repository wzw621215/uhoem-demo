//
//  ZBScanManager.m
//  scan3
//
//  Created by tailhuang on 15/9/21.
//  Copyright (c) 2015年 magook.com. All rights reserved.
//

#import "ZBScanManager.h"
#import "QRViewController.h"
@implementation ZBScanManager

+(void)scanInVC:(UINavigationController *)vc complishBlock:(void (^)(NSString *))block{

    if ([self validateCamera]) {

        QRViewController *qrVC = [[QRViewController alloc] init];

        [vc  pushViewController:qrVC animated:YES];

            qrVC.qrUrlBlock=^(NSString *url){

                    block(url);
                


            };


    }else{
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提  示" message:@"没有摄像头或摄像头不可用" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
    }
    

}
+(BOOL)validateCamera {

    return [UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera] &&
    [UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceRear];
}



@end
