//
//  ZBScanManager.h
//  scan3
//
//  Created by tailhuang on 15/9/21.
//  Copyright (c) 2015年 magook.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ZBScanManager : NSObject
+(void)scanInVC:(UIViewController *)vc complishBlock:(void (^)(NSString *url))complishBlock;
@end
