//
//  AppDelegate+UMShare.m
//  MagookReader
//
//  Created by zhoubin on 15/11/18.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "AppDelegate+UMShare.h"

@implementation AppDelegate (UMShare)
#pragma mark -友盟分享
-(void)umengShare{
    //设置友盟社会化组件appkey
    [UMSocialData setAppKey:UMAPPKEY];
    //支持不同的屏幕方向
    [UMSocialConfig setSupportedInterfaceOrientations:UIInterfaceOrientationMaskAll];
    
    //设置微信AppId，设置分享url，默认使用友盟的网址
    [UMSocialWechatHandler setWXAppId:@"wxd785c34afe0de110" appSecret:@"ada61250c4d01b3238f220130c59aa77" url:@"http://www.magook.com/"];
    //打开新浪微博的SSO开关
    [UMSocialSinaHandler openSSOWithRedirectURL:nil];
    //    [UMSocialSinaSSOHandler openNewSinaSSOWithRedirectURL:nil];
    //qq分享
    [UMSocialQQHandler setQQWithAppId:@"1101253706" appKey:@"f4xTNot3SbB7X6Nt" url:@"http://www.magook.com/"];
    //对未安装平台进行隐藏
    [UMSocialConfig hiddenNotInstallPlatforms:@[UMShareToQQ, UMShareToQzone, UMShareToWechatSession, UMShareToWechatTimeline]];
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    [UMSocialSnsService  applicationDidBecomeActive];
}
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
    return  [UMSocialSnsService handleOpenURL:url];
}
- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation
{
    return  [UMSocialSnsService handleOpenURL:url];
}

@end
