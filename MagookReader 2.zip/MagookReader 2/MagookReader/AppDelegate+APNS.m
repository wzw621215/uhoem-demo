//
//  AppDelegate+APNS.m
//  MagookReader
//
//  Created by zhoubin on 15/11/18.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "AppDelegate+APNS.h"
#define UMSYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define _IPHONE80_ 80000
@implementation AppDelegate (APNS)
#pragma  mark - 推送设置
-(void)UMessage{
    //set AppKey and AppSecret
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= _IPHONE80_
    if(UMSYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"8.0"))
    {
        //register remoteNotification types （iOS 8.0及其以上版本）
        UIMutableUserNotificationAction *action1 = [[UIMutableUserNotificationAction alloc] init];
        action1.identifier = @"action1_identifier";
        action1.title=@"Accept";
        action1.activationMode = UIUserNotificationActivationModeForeground;//当点击的时候启动程序
        
        UIMutableUserNotificationAction *action2 = [[UIMutableUserNotificationAction alloc] init];  //第二按钮
        action2.identifier = @"action2_identifier";
        action2.title=@"Reject";
        action2.activationMode = UIUserNotificationActivationModeBackground;//当点击的时候不启动程序，在后台处理
        action2.authenticationRequired = YES;//需要解锁才能处理，如果action.activationMode = UIUserNotificationActivationModeForeground;则这个属性被忽略；
        action2.destructive = YES;
        
        UIMutableUserNotificationCategory *categorys = [[UIMutableUserNotificationCategory alloc] init];
        categorys.identifier = @"category1";//这组动作的唯一标示
        [categorys setActions:@[action1,action2] forContext:(UIUserNotificationActionContextDefault)];
        
        UIUserNotificationSettings *userSettings = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeBadge|UIUserNotificationTypeSound|UIUserNotificationTypeAlert
                                                                                     categories:[NSSet setWithObject:categorys]];
        [UMessage registerRemoteNotificationAndUserNotificationSettings:userSettings];
        
    } else{
        //register remoteNotification types (iOS 8.0以下)
        [UMessage registerForRemoteNotificationTypes:UIRemoteNotificationTypeBadge
         |UIRemoteNotificationTypeSound
         |UIRemoteNotificationTypeAlert];
    }
#else
    //register remoteNotification types (iOS 8.0以下)
    [UMessage registerForRemoteNotificationTypes:UIRemoteNotificationTypeBadge
     |UIRemoteNotificationTypeSound
     |UIRemoteNotificationTypeAlert];
#endif
    //for log
    //    [UMessage setLogEnabled:YES];
}
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    NSLog(@"userInfo===%@", [userInfo JSONString]);
}
- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{

    NSLog(@"application:didFailToRegisterForRemoteNotificationsWithError: %@", error);
}
// ios7以后用这个处理后台任务接收到得远程通知
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler
{
    NSLog(@"userInfo-----%@", userInfo);
    
    [UMFeedback didReceiveRemoteNotification:userInfo];
    
    ApnsModel *model =[ApnsModel modelWithDic:userInfo];
    NSDictionary *apnsDic=[ApnsModel dicWithModel:model];
    
    [apnsDic setValue:0 forKey:@"isRead"];
    
    NSString *home = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString *path=[home stringByAppendingPathComponent:@"apns.plist"];
    
    NSFileManager *manager= [NSFileManager defaultManager];
    
    //    [manager removeItemAtPath:path error:nil];
    NSMutableArray *dataArray;
    
    if ([manager fileExistsAtPath:path]) {
        dataArray = [NSMutableArray arrayWithContentsOfFile:path];
        [dataArray addObject:apnsDic];
    }else{
        dataArray=[NSMutableArray arrayWithObject:apnsDic];
    }

    [dataArray writeToFile:path atomically:YES];

    if (userInfo) {
        completionHandler(UIBackgroundFetchResultNewData);
    }else{
        completionHandler(UIBackgroundFetchResultFailed);
    }
    
}
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{

    [UMessage registerDeviceToken:deviceToken];
    
    //    NSLog(@"umeng message alias is: %@", [UMFeedback uuid]);
    [UMessage addAlias:[UMFeedback uuid] type:[UMFeedback messageType] response:^(id responseObject, NSError *error) {
        if (error != nil) {
            NSLog(@"%@", error);
            NSLog(@"%@", responseObject);
        }
    }];
    NSString *devicetokenStr = [[[[deviceToken description] stringByReplacingOccurrencesOfString: @"<" withString: @""]stringByReplacingOccurrencesOfString: @">" withString: @""]stringByReplacingOccurrencesOfString: @" " withString: @""];
    NSLog(@"————————————————————%@",devicetokenStr);
    
    //记录devicetoken
    [[NSUserDefaults standardUserDefaults]setObject:devicetokenStr forKey:@"devicetoken"];
    [[NSUserDefaults standardUserDefaults]synchronize];

    [[GlobalSettings sharedSettings]configDevice];



    
    
}
@end
